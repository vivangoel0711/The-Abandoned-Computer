# PROJECT 98 — The Last User
    npm install
    npm run dev      # http://localhost:5173
    npm run build    # type-check + production build (deploy dist/ to Vercel)
