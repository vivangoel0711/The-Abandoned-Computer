import { APPLICATIONS } from '../../data/applications'
import { useWindowStore } from '../../store/windowStore'
import MessageBox from '../system/MessageBox'
import type { AppProps } from './types'

/** Shown for apps whose build step has not landed yet. */
export default function Unavailable({ windowId }: AppProps) {
  const win = useWindowStore((s) => s.windows.find((w) => w.id === windowId))
  const name = APPLICATIONS.find((a) => a.id === win?.appId)?.title ?? 'This program'
  return <MessageBox icon="warn" text={`${name} is not installed on this computer yet. Please run Setup again.`}
    onOk={() => useWindowStore.getState().closeWindow(windowId)} />
}
