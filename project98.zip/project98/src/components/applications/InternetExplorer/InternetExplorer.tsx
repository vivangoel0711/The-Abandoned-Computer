import { useMemo, useState } from 'react'
import type { AppProps } from '../types'
import MenuBar, { type Menu } from '../../system/MenuBar'

const pages: Record<string, { title: string; html: string }> = {
  'http://www.yahoo.com': { title: 'Yahoo! - Directory', html: '<h1 style="color:#800080">YAHOO!</h1><h3>Yet Another Hierarchically Organized Oracle</h3><p>Welcome to the Internet directory.</p><hr/><h3>Browse the Web</h3><ul><li>Arts & Humanities</li><li>Business & Economy</li><li>Computers & Internet</li><li>News & Media</li><li>Science</li><li>Society & Culture</li></ul><p><small>Yahoo! Directory archive · 2000</small></p>' },
  'http://www.google.com': { title: 'Google', html: '<center style="padding-top:45px"><h1 style="font:bold 42px Arial;color:#2455a4">Google!</h1><p>Search the web (local archive)</p><form id="search"><input name="q" style="width:280px;padding:5px"/><button>Google Search</button></form><p><small>Archived local search · 2001</small></p></center>' },
  'http://www.geocities.com/vmikhailov': { title: "Viktor's Homepage", html: '<body bgcolor="#ffffcc"><center><h2>Viktor M. — Personal Homepage</h2><p>New York · photographs, notes and links</p><hr/><p>Welcome. This page is a small record of places I have seen and people I have known.</p><p><a href="http://www.yahoo.com">My favourite links</a></p><p><i>Last updated: June 2002</i></p></center></body>' },
  'http://redwindow.local': { title: 'Red Window Archive', html: '<body bgcolor="#111" text="#d0d0d0"><h2 style="color:#d22">RED WINDOW // ARCHIVE GATEWAY</h2><hr/><p>Local archive mirror. Several records are incomplete.</p><ul><li>PROJECT ORION — communications research summary</li><li>PROJECT SENTINEL — archived correspondence</li><li>PROJECT NORTHSTAR — aerospace notes</li></ul><p>For personal notes, inspect C:\\My Documents\\Classified.</p><small>ARCHIVE NODE RW-03 · 14 AUG 2003</small></body>' },
  'http://sentinel.local': { title: 'Sentinel Research Archive', html: '<h2>Sentinel Research Archive</h2><p>Fictional archive mirror for Project 98.</p><p>Access level: READ ONLY</p><p>Records indexed through 13 August 2003.</p>' },
  'http://www.hotmail.com': { title: 'Hotmail', html: '<h2 style="color:#0066aa">hotmail</h2><p>Welcome to the archived webmail landing page.</p><p>This offline simulation preserves selected messages in the local Communications folder.</p>' },
}

export default function InternetExplorer({ params }: AppProps) {
  const initial = params?.url || 'http://www.yahoo.com'
  const [address, setAddress] = useState(initial)
  const [url, setUrl] = useState(initial)
  const [history, setHistory] = useState<string[]>([])
  const [forward, setForward] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const key = url.trim().replace(/\/$/, '').toLowerCase()
  const page = pages[key]
  const body = useMemo(() => page?.html || '', [page])
  const navigate = (value: string, record = true) => {
    let next = value.trim()
    if (!next) return
    if (!/^https?:\/\//i.test(next)) next = `http://${next}`
    if (record && next !== url) { setHistory(items => [...items, url]); setForward([]) }
    setLoading(true); setAddress(next); setUrl(next); setSearchQuery('')
    window.setTimeout(() => setLoading(false), 180)
  }
  const goBack = () => { const p = history[history.length - 1]; if (p) { setHistory(v => v.slice(0, -1)); setForward(v => [...v, url]); navigate(p, false) } }
  const goForward = () => { const p = forward[forward.length - 1]; if (p) { setForward(v => v.slice(0, -1)); setHistory(v => [...v, url]); navigate(p, false) } }
  const menus: Menu[] = [
    { label: 'File', items: [{ label: 'New Window', action: () => navigate('http://www.yahoo.com') }, { label: 'Save As...', action: () => window.alert('Saving web pages is simulated.') }, { label: 'Close', action: () => { setUrl('about:blank'); setAddress('about:blank') } }] },
    { label: 'Edit', items: [{ label: 'Select All', action: () => document.execCommand('selectAll') }, { label: 'Copy', action: () => document.execCommand('copy') }] },
    { label: 'View', items: [{ label: 'Refresh', action: () => navigate(url, false) }, { label: 'Text Size: Medium', disabled: true }] },
    { label: 'Favorites', items: [{ label: 'Yahoo!', action: () => navigate('http://www.yahoo.com') }, { label: 'Google', action: () => navigate('http://www.google.com') }, { label: 'Viktor Homepage', action: () => navigate('http://www.geocities.com/vmikhailov') }, { label: 'Red Window Archive', action: () => navigate('http://redwindow.local') }, { label: 'Sentinel Archive', action: () => navigate('http://sentinel.local') }, { label: 'Hotmail', action: () => navigate('http://www.hotmail.com') }] },
    { label: 'Tools', items: [{ label: 'Internet Options...', action: () => window.alert('Internet Options · Offline mode') }] },
    { label: 'Help', items: [{ label: 'About Internet Explorer', action: () => window.alert('Microsoft Internet Explorer\nVersion 5.00.2614.3500') }] },
  ]
  const toolbar = [['←', 'Back', goBack], ['→', 'Forward', goForward], ['×', 'Stop', () => setLoading(false)], ['↻', 'Refresh', () => navigate(url, false)], ['⌂', 'Home', () => navigate('http://www.yahoo.com')]] as const
  return <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#c0c0c0', fontSize: 12 }}>
    <MenuBar menus={menus} />
    <div style={{ display: 'flex', gap: 3, padding: 4, borderBottom: '1px solid #888' }}>{toolbar.map(([icon, label, action]) => <button key={label} className="w98-button" title={label} onClick={action}>{icon}</button>)}</div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 6px' }}><b>Address</b><input className="w98-field" value={address} onChange={e => setAddress(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') navigate(address) }} style={{ flex: 1, padding: 3 }} /><button className="w98-button" onClick={() => navigate(address)}>Go</button></div>
    <div style={{ flex: 1, overflow: 'auto', background: '#fff', border: '1px solid #777', margin: '0 4px', padding: 16 }}>
      {loading ? <p>Connecting...</p> : key === 'about:blank' ? null : page ? <>
        <div dangerouslySetInnerHTML={{ __html: body }} onClick={e => { const link = (e.target as HTMLElement).closest('a'); if (link) { e.preventDefault(); navigate(link.getAttribute('href') || '') } }} onSubmit={e => { e.preventDefault(); const input = (e.target as HTMLFormElement).querySelector('input') as HTMLInputElement; if (input?.value) setSearchQuery(input.value) }} />
        {key === 'http://www.google.com' && searchQuery && <div style={{ marginTop: 14, borderTop: '1px solid #ddd', paddingTop: 8 }}><b>Local results for “{searchQuery}”</b><p><a href="http://redwindow.local" onClick={e => { e.preventDefault(); navigate('http://redwindow.local') }}>Red Window Archive</a> — archived research index</p><p><a href="http://www.geocities.com/vmikhailov" onClick={e => { e.preventDefault(); navigate('http://www.geocities.com/vmikhailov') }}>Viktor's Homepage</a> — personal notes and photographs</p></div>}
      </> : <><h2>Cannot find server</h2><p>Internet Explorer cannot display the webpage.</p><p>The requested address is not available in this offline Windows 98 simulation.</p><p>Try one of the archived sites in Favorites.</p></>}
    </div>
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 7px', fontSize: 11 }}><span>{loading ? 'Opening page...' : 'Done'}</span><span>Internet | Local intranet</span></div>
  </div>
}
