import { useState } from 'react'

const compute = (a: number, b: number, o: string) =>
  o === '+' ? a + b : o === '-' ? a - b : o === '*' ? a * b : b === 0 ? NaN : a / b
const fmt = (n: number) => (Number.isFinite(n) ? String(parseFloat(n.toPrecision(12))) : 'Cannot divide by zero')

export default function Calculator() {
  const [disp, setDisp] = useState('0')
  const [acc, setAcc] = useState<number | null>(null)
  const [op, setOp] = useState<string | null>(null)
  const [fresh, setFresh] = useState(true)
  const cur = parseFloat(disp)

  const digit = (d: string) => {
    if (fresh) { setDisp(d === '.' ? '0.' : d); setFresh(false); return }
    if ((d === '.' && disp.includes('.')) || disp.length >= 12) return
    setDisp(disp === '0' && d !== '.' ? d : disp + d)
  }
  const operator = (o: string) => {
    if (Number.isNaN(cur)) return
    if (acc !== null && op && !fresh) { const r = compute(acc, cur, op); setDisp(fmt(r)); setAcc(Number.isFinite(r) ? r : null) }
    else setAcc(cur)
    setOp(o); setFresh(true)
  }
  const equals = () => {
    if (Number.isNaN(cur) || acc === null || !op) return
    setDisp(fmt(compute(acc, cur, op))); setAcc(null); setOp(null); setFresh(true)
  }
  const clear = () => { setDisp('0'); setAcc(null); setOp(null); setFresh(true) }

  const keys: [string, () => void, number?][] = [
    ['CE', () => { setDisp('0'); setFresh(true) }], ['C', clear], ['±', () => !Number.isNaN(cur) && setDisp(fmt(-cur))], ['/', () => operator('/')],
    ['7', () => digit('7')], ['8', () => digit('8')], ['9', () => digit('9')], ['*', () => operator('*')],
    ['4', () => digit('4')], ['5', () => digit('5')], ['6', () => digit('6')], ['-', () => operator('-')],
    ['1', () => digit('1')], ['2', () => digit('2')], ['3', () => digit('3')], ['+', () => operator('+')],
    ['0', () => digit('0')], ['.', () => digit('.')], ['=', equals, 2],
  ]

  return (
    <div style={{ padding: 8 }}>
      <div className="w98-field" style={{ height: 24, textAlign: 'right', padding: '4px 6px', fontSize: 14, fontFamily: "'Courier New', monospace", overflow: 'hidden', marginBottom: 8 }}>{disp}</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 4 }}>
        {keys.map(([label, fn, span]) => (
          <button key={label} className="w98-button" style={{ minWidth: 0, height: 28, padding: 0, gridColumn: span ? `span ${span}` : undefined,
            color: '/*-+='.includes(label) ? '#c00' : '#000080', fontWeight: 'bold' }} onClick={fn}>{label}</button>
        ))}
      </div>
    </div>
  )
}
