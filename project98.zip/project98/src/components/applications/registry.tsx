import type { ComponentType } from 'react'
import type { AppId } from '../../data/applications'
import type { AppProps } from './types'
import Calculator from './Calculator/Calculator'
import FileExplorer from './FileExplorer/FileExplorer'
import MyComputer from './MyComputer/MyComputer'
import Printers from './Printers/Printers'
import RunDialog from './Run/RunDialog'
import ShutDownDialog from './Run/ShutDownDialog'
import Notepad from './Notepad/Notepad'
import InternetExplorer from './InternetExplorer/InternetExplorer'
import Minesweeper from './Minesweeper/Minesweeper'
import ImageViewer from './ImageViewer/ImageViewer'
import Unavailable from './Unavailable'

const COMPONENTS: Record<AppId, ComponentType<AppProps>> = {
  'my-computer': MyComputer, 'file-explorer': FileExplorer, 'my-documents': Unavailable,
  'recycle-bin': Unavailable, 'internet-explorer': InternetExplorer, notepad: Notepad,
  calculator: Calculator, paint: Unavailable, minesweeper: Minesweeper, solitaire: Unavailable,
  'super-retro-98': Unavailable, 'media-player': Unavailable, cmd: Unavailable,
  'control-panel': Unavailable, printers: Printers, 'image-viewer': ImageViewer,
  find: Unavailable, run: RunDialog, shutdown: ShutDownDialog,
}
export const getAppComponent = (id: AppId) => COMPONENTS[id]
