import type { ComponentType } from 'react'
import type { AppId } from '../../data/applications'
import type { AppProps } from './types'
import Calculator from './Calculator/Calculator'
import FileExplorer from './FileExplorer/FileExplorer'
import MyComputer from './MyComputer/MyComputer'
import Printers from './Printers/Printers'
import RunDialog from './Run/RunDialog'
import ShutDownDialog from './Run/ShutDownDialog'
import Unavailable from './Unavailable'

/**
 * Single source of truth for components. Typed as a complete Record so adding an
 * AppId without deciding its component is a compile error. Apps that are not built
 * yet point at Unavailable AND have `implemented: false` in data/applications.ts,
 * which keeps them out of the Start menu and the Run dialog.
 */
const COMPONENTS: Record<AppId, ComponentType<AppProps>> = {
  'my-computer': MyComputer,
  'file-explorer': FileExplorer,
  'my-documents': Unavailable, // shortcut: resolved to file-explorer by windowStore.openApp
  'recycle-bin': Unavailable,
  'internet-explorer': Unavailable,
  notepad: Unavailable,
  calculator: Calculator,
  paint: Unavailable,
  minesweeper: Unavailable,
  solitaire: Unavailable,
  'super-retro-98': Unavailable,
  'media-player': Unavailable,
  cmd: Unavailable,
  'control-panel': Unavailable,
  printers: Printers,
  'image-viewer': Unavailable,
  find: Unavailable,
  run: RunDialog,
  shutdown: ShutDownDialog,
}

export const getAppComponent = (id: AppId) => COMPONENTS[id]
