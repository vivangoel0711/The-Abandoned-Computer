import { useWindowStore } from '../../../store/windowStore'
import ExplorerShell, { type ShellItem } from '../shared/ExplorerShell'
import type { AppProps } from '../types'

const open = useWindowStore.getState

const ITEMS: ShellItem[] = [
  { id: 'a', label: '3½ Floppy (A:)', icon: 'floppy', description: '3½-Inch Floppy Disk',
    onOpen: (n) => n('error', 'A:\\ is not accessible.\n\nThe device is not ready.') },
  { id: 'c', label: 'Local Disk (C:)', icon: 'drive', description: 'Local Disk\n\nUsed: 1.94 GB\nFree: 86.0 MB\nCapacity: 2.03 GB',
    onOpen: () => open().openApp('file-explorer', { path: 'C:\\' }) },
  { id: 'd', label: 'BACKUP_0803 (D:)', icon: 'cdrom', description: 'CD-ROM Disc\n\nA disc is in the drive.',
    onOpen: () => open().openApp('file-explorer', { path: 'D:\\' }) },
  { id: 'cp', label: 'Control Panel', icon: 'control-panel', description: 'Change settings for your computer and installed software.',
    onOpen: () => open().openApp('control-panel') },
  { id: 'pr', label: 'Printers', icon: 'printers', description: 'Install, remove, and view the status of printers.',
    onOpen: () => open().openApp('printers') },
  { id: 'du', label: 'Dial-Up Networking', icon: 'dialup', description: 'Connect to other computers using a modem.',
    onOpen: (n) => n('warn', 'Dial-Up Networking cannot find a modem.\n\nTo install a modem, double-click Modems in Control Panel.') },
]

export default function MyComputer({ windowId }: AppProps) {
  return <ExplorerShell windowId={windowId} title="My Computer" icon="my-computer" address="My Computer" items={ITEMS} />
}
