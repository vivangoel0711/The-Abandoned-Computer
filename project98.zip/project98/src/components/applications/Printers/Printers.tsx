import ExplorerShell, { type ShellItem } from '../shared/ExplorerShell'
import type { AppProps } from '../types'

const ITEMS: ShellItem[] = [
  { id: 'add', label: 'Add Printer', icon: 'printer', description: 'Starts the Add Printer Wizard.',
    onOpen: (n) => n('error', 'Unable to start the Add Printer Wizard.\n\nThe print spooler is not responding.') },
  { id: 'gen', label: 'Generic / Text Only', icon: 'printer', description: 'Status: Ready\nDocuments: 0\nPort: LPT1:',
    onOpen: (n) => n('info', 'Generic / Text Only\n\nStatus: Ready\nDocuments in queue: 0') },
]

export default function Printers({ windowId }: AppProps) {
  return <ExplorerShell windowId={windowId} title="Printers" icon="printers" address="My Computer\Printers" items={ITEMS} />
}
