import { useState } from 'react'
import { useWindowStore } from '../../../store/windowStore'
import PixelIcon, { type IconId } from '../../desktop/PixelIcon'
import MenuBar, { type Menu } from '../../system/MenuBar'
import MessageBox from '../../system/MessageBox'

export type NoticeIcon = 'error' | 'warn' | 'info'
export type Notify = (icon: NoticeIcon, text: string) => void
export interface ShellItem { id: string; label: string; icon: IconId; description?: string; onOpen: (notify: Notify) => void }

interface Props { windowId: string; title: string; icon: IconId; address: string; items: ShellItem[] }

const ABOUT = 'Microsoft Windows 98\nVersion 4.10.1998\n\nThis product is registered to:\nUser\n\nProduct ID: 54321-OEM-0000007-00001'

/** Classic Explorer chrome (menu bar, toolbar, address bar, content, status bar), reused by My Computer, Printers and later Control Panel / File Explorer. */
export default function ExplorerShell({ windowId, title, icon, address, items }: Props) {
  const [view, setView] = useState<'icons' | 'list'>('icons')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [notice, setNotice] = useState<{ icon: NoticeIcon; text: string } | null>(null)
  const notify: Notify = (i, text) => setNotice({ icon: i, text })

  const menus: Menu[] = [
    { label: 'File', items: [{ label: 'Close', action: () => useWindowStore.getState().closeWindow(windowId) }] },
    { label: 'Edit', items: [
      { label: 'Select All', action: () => setSelected(new Set(items.map((i) => i.id))) },
      { label: 'Invert Selection', action: () => setSelected(new Set(items.filter((i) => !selected.has(i.id)).map((i) => i.id))) },
    ] },
    { label: 'View', items: [
      { label: 'Large Icons', checked: view === 'icons', action: () => setView('icons') },
      { label: 'List', checked: view === 'list', action: () => setView('list') },
    ] },
    { label: 'Help', items: [{ label: 'About Windows 98', action: () => notify('info', ABOUT) }] },
  ]

  const pick = (id: string, multi: boolean) =>
    setSelected((s) => { const n = multi ? new Set(s) : new Set<string>(); if (multi && s.has(id)) n.delete(id); else n.add(id); return n })

  const only = selected.size === 1 ? items.find((i) => selected.has(i.id)) : undefined
  const tb: React.CSSProperties = { minWidth: 0, padding: '2px 8px', height: 22 }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
      <MenuBar menus={menus} />
      <div style={{ display: 'flex', gap: 4, padding: 3, borderBottom: '1px solid #808080', boxShadow: '0 1px #fff', flex: 'none' }}>
        <button className="w98-button" style={tb} disabled>← Back</button>
        <button className="w98-button" style={tb} disabled>→ Forward</button>
        <button className="w98-button" style={tb} disabled>↑ Up</button>
        <div style={{ width: 2, borderLeft: '1px solid #808080', borderRight: '1px solid #fff', margin: '0 2px' }} />
        <button className={`w98-button ${view === 'icons' ? 'pressed' : ''}`} style={tb} onClick={() => setView('icons')}>Large Icons</button>
        <button className={`w98-button ${view === 'list' ? 'pressed' : ''}`} style={tb} onClick={() => setView('list')}>List</button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '3px 4px', flex: 'none' }}>
        <span>Address</span>
        <div className="w98-field" style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4, padding: '2px 4px' }}><PixelIcon id={icon} size={14} />{address}</div>
      </div>
      <div className="w98-field" style={{ flex: 1, minHeight: 0, display: 'flex', margin: '0 3px' }}>
        <div style={{ width: 150, flex: 'none', padding: 10, borderRight: '1px solid #c0c0c0', overflow: 'auto' }}>
          <div style={{ fontSize: 18, fontWeight: 'bold', fontFamily: 'Arial, sans-serif', marginBottom: 14 }}>{only ? only.label : title}</div>
          <div style={{ whiteSpace: 'pre-line', color: '#444', lineHeight: '14px' }}>
            {only ? only.description ?? '' : 'Select an item to view its description.'}
          </div>
        </div>
        <div tabIndex={0} style={{ flex: 1, overflow: 'auto', padding: 6, outline: 'none', display: 'flex', flexWrap: 'wrap', alignContent: 'flex-start',
          flexDirection: view === 'list' ? 'column' : 'row', gap: view === 'list' ? 2 : 4 }}
          onPointerDown={(e) => { if (e.target === e.currentTarget) setSelected(new Set()) }}
          onKeyDown={(e) => { if (e.key === 'Enter' && only) only.onOpen(notify) }}>
          {items.map((it) => {
            const sel = selected.has(it.id)
            const label = <span style={{ padding: '1px 3px', ...(sel ? { background: '#000080', color: '#fff', outline: '1px dotted #ff0' } : {}) }}>{it.label}</span>
            return view === 'icons' ? (
              <div key={it.id} style={{ width: 90, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, textAlign: 'center', padding: 2 }}
                onClick={(e) => pick(it.id, e.ctrlKey)} onDoubleClick={() => it.onOpen(notify)}>
                <PixelIcon id={it.icon} />{label}
              </div>
            ) : (
              <div key={it.id} style={{ display: 'flex', alignItems: 'center', gap: 4 }} onClick={(e) => pick(it.id, e.ctrlKey)} onDoubleClick={() => it.onOpen(notify)}>
                <PixelIcon id={it.icon} size={16} />{label}
              </div>
            )
          })}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 2, padding: 3, flex: 'none' }}>
        <div className="w98-inset" style={{ flex: 1, padding: '2px 6px', boxShadow: 'inset 1px 1px #808080, inset -1px -1px #fff', background: 'none' }}>
          {only ? only.label : `${items.length} object(s)`}
        </div>
        <div style={{ width: 130, padding: '2px 6px', display: 'flex', alignItems: 'center', gap: 4, boxShadow: 'inset 1px 1px #808080, inset -1px -1px #fff' }}>
          <PixelIcon id={icon} size={14} />{title}
        </div>
      </div>
      {notice && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 30 }}>
          <div className="w98-raised" style={{ padding: 3, minWidth: 260, maxWidth: 340 }}>
            <div className="w98-titlebar" style={{ height: 18, padding: '1px 4px', display: 'flex', alignItems: 'center' }}>{title}</div>
            <MessageBox icon={notice.icon} text={notice.text} onOk={() => setNotice(null)} />
          </div>
        </div>
      )}
    </div>
  )
}
