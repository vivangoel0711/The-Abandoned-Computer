import type { Params } from '../../data/applications'

export interface AppProps {
  windowId: string
  /** true when this window is focused and not minimized (games pause when false) */
  active: boolean
  params?: Params
}
