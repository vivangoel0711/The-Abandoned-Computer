import { useState } from 'react'
import { APPLICATIONS, isImplemented } from '../../../data/applications'
import { useWindowStore } from '../../../store/windowStore'
import MessageBox from '../../system/MessageBox'
import type { AppProps } from '../types'

const strip = (s: string) => s.trim().toLowerCase().replace(/\.exe$/, '')

export default function RunDialog({ windowId }: AppProps) {
  const [value, setValue] = useState('')
  const [error, setError] = useState(false)
  const close = () => useWindowStore.getState().closeWindow(windowId)

  const submit = () => {
    const key = strip(value)
    const def = APPLICATIONS.find((a) => strip(a.exe) === key || a.aliases?.includes(key))
    if (def && isImplemented(def.id)) { useWindowStore.getState().openApp(def.id); close() }
    else setError(true)
  }

  if (error) return <MessageBox text={`Cannot find the file '${value.trim()}' (or one of its components). Make sure the path and filename are correct and that all required libraries are available.`} onOk={() => setError(false)} />

  return (
    <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ lineHeight: '14px' }}>Type the name of a program, folder, document, or Internet resource, and Windows will open it for you.</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <label htmlFor="run-input">Open:</label>
        <input id="run-input" autoFocus className="w98-field" style={{ flex: 1, border: 0, padding: '3px 4px', font: 'inherit', outline: 'none' }}
          value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && value.trim()) submit() }} />
      </div>
      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
        <button className="w98-button" disabled={!value.trim()} onClick={submit}>OK</button>
        <button className="w98-button" onClick={close}>Cancel</button>
      </div>
    </div>
  )
}
