import { useState } from 'react'
import { useWindowStore } from '../../../store/windowStore'
import type { AppProps } from '../types'

export default function ShutDownDialog({ windowId }: AppProps) {
  const [choice, setChoice] = useState<'shutdown' | 'restart'>('shutdown')
  const close = () => useWindowStore.getState().closeWindow(windowId)
  const ok = () => (choice === 'shutdown' ? useWindowStore.getState().shutDown() : useWindowStore.getState().restart())

  return (
    <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div>What do you want the computer to do?</div>
      {([['shutdown', 'Shut down'], ['restart', 'Restart']] as const).map(([v, label]) => (
        <label key={v} style={{ display: 'flex', gap: 6, alignItems: 'center', marginLeft: 12 }}>
          <input type="radio" name="power" checked={choice === v} onChange={() => setChoice(v)} /> {label}
        </label>
      ))}
      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end', marginTop: 6 }}>
        <button className="w98-button" autoFocus onClick={ok}>OK</button>
        <button className="w98-button" onClick={close}>Cancel</button>
      </div>
    </div>
  )
}
