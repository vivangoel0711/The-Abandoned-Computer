import { useEffect, useState } from 'react'
import type { AppProps } from '../types'
import MenuBar, { type Menu } from '../../system/MenuBar'
import { useFsStore } from '../../../store/fsStore'
import * as core from '../../../fs/core'

export default function Notepad({ params }: AppProps) {
  const fs = useFsStore(s => s.fs), writeFile = useFsStore(s => s.writeFile)
  const initial = params?.nodeId ? fs.nodes[params.nodeId] : undefined
  const [name, setName] = useState(initial?.name || 'Untitled')
  const [path, setPath] = useState(initial?.parent ? core.pathOf(fs, initial.parent) : 'C:\\My Documents')
  const [text, setText] = useState(initial?.content || '')
  const [dirty, setDirty] = useState(false)
  const [wrap, setWrap] = useState(true)
  const [notice, setNotice] = useState('')
  useEffect(() => { if (params?.nodeId) { const n = fs.nodes[params.nodeId]; if (n) { setName(n.name); setText(n.content || ''); setPath(n.parent ? core.pathOf(fs,n.parent) : 'C:\\'); setDirty(false) } } }, [params?.nodeId])
  const save = () => { const folder = core.resolve(fs,path); if (!folder || folder.kind !== 'folder') { setNotice('The destination folder cannot be found.'); return }
    const r = writeFile(folder.id,name,text); if (!r.ok) setNotice(r.message); else setDirty(false) }
  const saveAs = () => { const n = window.prompt('Save as:', name); if (n?.trim()) { setName(n.trim()); const folder = core.resolve(fs,path); if(folder){const r=writeFile(folder.id,n.trim(),text); if(!r.ok)setNotice(r.message);else setDirty(false)} } }
  const menus: Menu[] = [
    {label:'File',items:[{label:'New',action:()=>{setName('Untitled');setPath('C:\\My Documents');setText('');setDirty(false)}},{label:'Open...',action:()=>{const p=window.prompt('Open file path:',path+'\\'+name);if(p){const n=core.resolve(fs,p);if(n?.kind==='file'){setName(n.name);setPath(n.parent?core.pathOf(fs,n.parent):'C:\\');setText(n.content||'');setDirty(false)}else setNotice('File not found or cannot be opened as text.')}}},{label:'Save',action:save},{label:'Save As...',action:saveAs},{label:'',sep:true},{label:'Page Setup...',action:()=>setNotice('Page setup is simulated.')},{label:'Print',action:()=>setNotice('Printing is simulated in Project 98.')}]},
    {label:'Edit',items:[{label:'Undo',action:()=>document.execCommand('undo')},{label:'Cut',action:()=>document.execCommand('cut')},{label:'Copy',action:()=>document.execCommand('copy')},{label:'Paste',action:()=>document.execCommand('paste')},{label:'Select All',action:()=>document.execCommand('selectAll')},{label:'Time/Date',action:()=>setText(t=>t+new Date().toLocaleString())}]},
    {label:'Search',items:[{label:'Find...',action:()=>{const q=window.prompt('Find:');if(q){const i=text.toLowerCase().indexOf(q.toLowerCase());setNotice(i>=0?`Found “${q}” at character ${i}.`:`Cannot find “${q}”.`)}}}]},
    {label:'Help',items:[{label:'About Notepad',action:()=>setNotice('Notepad\nVersion 4.10.1998')}]}
  ]
  return <div style={{height:'100%',display:'flex',flexDirection:'column',background:'#c0c0c0'}}><MenuBar menus={menus}/><div style={{padding:'3px 6px',fontSize:11,color:'#444'}}>{path}\\{name}{dirty?' *':''}</div><textarea aria-label="Notepad document" value={text} onChange={e=>{setText(e.target.value);setDirty(true)}} wrap={wrap?'soft':'off'} spellCheck={false} style={{flex:1,resize:'none',border:'2px inset #fff',outline:'none',padding:5,fontFamily:'Lucida Console, monospace',fontSize:13,whiteSpace:wrap?'pre-wrap':'pre',overflow:'auto'}}/><div style={{display:'flex',justifyContent:'space-between',padding:'3px 6px',fontSize:11}}><span>{text.length} characters</span><label><input type="checkbox" checked={wrap} onChange={e=>setWrap(e.target.checked)}/> Word Wrap</label></div>{notice&&<div style={{position:'absolute',inset:0,background:'#0003',display:'grid',placeItems:'center'}}><div className="w98-raised" style={{padding:10,minWidth:250,whiteSpace:'pre-line'}}>{notice}<div style={{textAlign:'right',marginTop:12}}><button className="w98-button" onClick={()=>setNotice('')}>OK</button></div></div></div>}</div>
}
