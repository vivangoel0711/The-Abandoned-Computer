import { useWindowStore } from '../../store/windowStore'
import WindowFrame from './WindowFrame'

export default function WindowManager() {
  const windows = useWindowStore((s) => s.windows)
  const focusedId = useWindowStore((s) => s.focusedId)
  return (
    <div style={{ position: 'fixed', inset: '0 0 28px 0', pointerEvents: 'none', zIndex: 1, overflow: 'hidden' }}>
      {windows.map((w) => <WindowFrame key={w.id} win={w} focused={w.id === focusedId} />)}
    </div>
  )
}
