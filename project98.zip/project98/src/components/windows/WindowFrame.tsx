import { useRef } from 'react'
import { APPLICATIONS } from '../../data/applications'
import { useWindowStore, type WinState } from '../../store/windowStore'
import { getAppComponent } from '../applications/registry'
import WindowTitleBar from './WindowTitleBar'

export default function WindowFrame({ win, focused }: { win: WinState; focused: boolean }) {
  const def = APPLICATIONS.find((a) => a.id === win.appId)!
  const Body = getAppComponent(win.appId)
  const resize = useRef<{ sx: number; sy: number; w: number; h: number } | null>(null)

  const geometry: React.CSSProperties = win.maximized
    ? { left: 0, top: 0, width: '100%', height: '100%' }
    : { left: win.x, top: win.y, width: win.w, height: win.h }

  return (
    <div
      className="w98-raised"
      style={{ position: 'absolute', pointerEvents: 'auto', zIndex: win.z, padding: 3, display: win.minimized ? 'none' : 'flex', flexDirection: 'column', ...geometry }}
      onPointerDownCapture={() => {
        const s = useWindowStore.getState()
        if (s.focusedId !== win.id) s.focus(win.id)
      }}
    >
      <WindowTitleBar win={win} def={def} focused={focused} />
      <div style={{ flex: 1, minHeight: 0, overflow: 'auto', position: 'relative', background: '#c0c0c0', marginTop: 2 }}>
        <Body windowId={win.id} active={focused && !win.minimized} params={win.params} />
      </div>
      {def.kind === 'window' && !win.maximized && (
        <div
          style={{ position: 'absolute', right: 0, bottom: 0, width: 14, height: 14, cursor: 'nwse-resize', touchAction: 'none' }}
          onPointerDown={(e) => { e.stopPropagation(); resize.current = { sx: e.clientX, sy: e.clientY, w: win.w, h: win.h }; e.currentTarget.setPointerCapture(e.pointerId) }}
          onPointerMove={(e) => { const r = resize.current; if (r) useWindowStore.getState().setRect(win.id, { w: r.w + e.clientX - r.sx, h: r.h + e.clientY - r.sy }) }}
          onPointerUp={() => { resize.current = null }}
        />
      )}
    </div>
  )
}
