import { useRef } from 'react'
import type { AppDefinition } from '../../data/applications'
import { useWindowStore, type WinState } from '../../store/windowStore'
import PixelIcon from '../desktop/PixelIcon'
import WindowControls from './WindowControls'

interface Props { win: WinState; def: AppDefinition; focused: boolean }

export default function WindowTitleBar({ win, def, focused }: Props) {
  const drag = useRef<{ dx: number; dy: number } | null>(null)
  const st = useWindowStore.getState

  const down = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0 || win.maximized) return
    drag.current = { dx: e.clientX - win.x, dy: e.clientY - win.y }
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const move = (e: React.PointerEvent) => {
    const d = drag.current
    if (d) st().setRect(win.id, { x: e.clientX - d.dx, y: e.clientY - d.dy })
  }

  return (
    <div
      className={focused ? 'w98-titlebar' : undefined}
      style={{ height: 18, display: 'flex', alignItems: 'center', gap: 4, padding: '1px 2px', flex: 'none', touchAction: 'none',
        ...(focused ? {} : { background: 'linear-gradient(90deg,#808080,#b8b8b8)', color: '#d8d8d8', fontWeight: 'bold' }) }}
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={() => { drag.current = null }}
      onDoubleClick={() => def.kind === 'window' && st().toggleMaximize(win.id)}
    >
      <PixelIcon id={def.icon} size={14} />
      <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{win.title}</span>
      <WindowControls kind={def.kind} maximized={win.maximized}
        onMin={() => st().minimize(win.id)} onMax={() => st().toggleMaximize(win.id)} onClose={() => st().closeWindow(win.id)} />
    </div>
  )
}
