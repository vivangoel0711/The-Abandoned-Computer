import type { WindowKind } from '../../data/applications'

interface Props { kind: WindowKind; maximized: boolean; onMin: () => void; onMax: () => void; onClose: () => void }

const btn: React.CSSProperties = { width: 16, height: 14, minWidth: 0, padding: 0, fontSize: 10, lineHeight: '10px', fontWeight: 'bold', color: '#000' }

export default function WindowControls({ kind, maximized, onMin, onMax, onClose }: Props) {
  const stop = (e: React.PointerEvent) => e.stopPropagation()
  return (
    <div style={{ display: 'flex', gap: 2, marginLeft: 'auto' }} onPointerDown={stop} onDoubleClick={(e) => e.stopPropagation()}>
      {kind !== 'dialog' && <button className="w98-button" style={btn} aria-label="Minimize" onClick={onMin}>_</button>}
      {kind === 'window' && <button className="w98-button" style={btn} aria-label={maximized ? 'Restore' : 'Maximize'} onClick={onMax}>{maximized ? '❐' : '□'}</button>}
      <button className="w98-button" style={{ ...btn, marginLeft: 2 }} aria-label="Close" onClick={onClose}>✕</button>
    </div>
  )
}
