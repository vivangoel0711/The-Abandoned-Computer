// Local-only check for the fictional login. Never stored, never shown in the UI.
// Salted djb2 comparison: this keeps the secret out of plain sight; it is NOT real security.
const hash = (s: string) => {
  let h = 5381
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0
  return h
}
export const checkPassword = (input: string): boolean => hash('w98:' + input) === 4175275277
