import { useEffect, useState } from 'react'
import { useWindowStore } from '../../store/windowStore'

export default function ShutdownScreen() {
  const [done, setDone] = useState(false)
  const restart = useWindowStore((s) => s.restart)

  useEffect(() => {
    const t = setTimeout(() => setDone(true), 2200)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    if (!done) return
    window.addEventListener('keydown', restart)
    window.addEventListener('pointerdown', restart)
    return () => { window.removeEventListener('keydown', restart); window.removeEventListener('pointerdown', restart) }
  }, [done, restart])

  return (
    <div style={{ position: 'fixed', inset: 0, background: done ? '#000' : '#008080', display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#ff8c00', fontFamily: "'Courier New', monospace", fontSize: 22, textAlign: 'center', zIndex: 100001, cursor: done ? 'pointer' : 'wait' }}>
      {done ? (
        <div>IT'S SAFE TO TURN OFF YOUR COMPUTER NOW.<div style={{ color: '#555', fontSize: 12, marginTop: 24 }}>(click or press any key to power on)</div></div>
      ) : (
        <div style={{ color: '#fff', fontFamily: 'Tahoma, sans-serif', fontSize: 16 }}>Windows is shutting down...</div>
      )}
    </div>
  )
}
