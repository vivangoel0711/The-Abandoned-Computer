interface Props { icon?: 'error' | 'warn' | 'info'; text: string; onOk: () => void }

const GLYPH = { error: ['#f00', '×'], warn: ['#ffd700', '!'], info: ['#1084d0', 'i'] } as const

export default function MessageBox({ icon = 'error', text, onOk }: Props) {
  const [bg, ch] = GLYPH[icon]
  return (
    <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 14, alignItems: 'center' }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
        <div style={{ width: 32, height: 32, flex: 'none', borderRadius: icon === 'warn' ? 0 : 16, background: bg, border: '1px solid #000',
          color: icon === 'warn' ? '#000' : '#fff', fontWeight: 'bold', fontSize: 20, textAlign: 'center', lineHeight: '30px' }}>{ch}</div>
        <div style={{ lineHeight: '14px', userSelect: 'text', whiteSpace: 'pre-line' }}>{text}</div>
      </div>
      <button className="w98-button" autoFocus onClick={onOk}>OK</button>
    </div>
  )
}
