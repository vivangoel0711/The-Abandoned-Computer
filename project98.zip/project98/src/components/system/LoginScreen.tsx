import { useEffect, useRef, useState } from 'react'
import { useDesktopStore } from '../../store/desktopStore'
import MessageBox from './MessageBox'
import { checkPassword } from './auth'

interface Modal { title: string; icon: 'error' | 'warn' | 'info'; text: string }

function Dialog({ title, children, width }: { title: string; children: React.ReactNode; width?: number }) {
  return (
    <div className="w98-raised" style={{ padding: 3, width, minWidth: 260 }}>
      <div className="w98-titlebar" style={{ height: 18, padding: '1px 4px', display: 'flex', alignItems: 'center' }}>{title}</div>
      {children}
    </div>
  )
}

const Flag = () => (
  <svg width="40" height="40" viewBox="0 0 16 16" shapeRendering="crispEdges">
    <rect x="1" y="2" width="6" height="6" fill="#f00"/><rect x="8" y="1" width="7" height="7" fill="#0a0"/>
    <rect x="1" y="9" width="6" height="6" fill="#00f"/><rect x="8" y="9" width="7" height="6" fill="#fc0"/>
  </svg>
)

export default function LoginScreen() {
  const setAuthed = useDesktopStore((s) => s.setAuthed)
  const [pw, setPw] = useState('')
  const [fails, setFails] = useState(0)
  const [modal, setModal] = useState<Modal | null>(null)
  const [welcome, setWelcome] = useState(false)
  const input = useRef<HTMLInputElement>(null)

  useEffect(() => { if (!modal && !welcome) input.current?.focus() }, [modal, welcome])

  useEffect(() => {
    if (!welcome) return
    const t = setTimeout(() => setAuthed(true), 2600)
    return () => clearTimeout(t)
  }, [welcome, setAuthed])

  const submit = () => {
    if (modal || welcome) return
    if (checkPassword(pw)) { setWelcome(true); return }
    const n = fails + 1
    setPw('')
    if (n >= 3) {
      setFails(0) // never a permanent lockout: the counter resets and the user may retry
      setModal({ title: 'SECURITY WARNING', icon: 'warn',
        text: 'Multiple unauthorized login attempts detected.\n\nThis computer has been flagged.\n\nClick OK to try again.' })
    } else {
      setFails(n)
      setModal({ title: 'Welcome to Windows', icon: 'error', text: 'The password you supplied is incorrect. Please re-enter your password.' })
    }
  }

  const cancel = () => {
    setPw('')
    setModal({ title: 'Welcome to Windows', icon: 'info', text: 'This computer is restricted. You must enter a password to continue.' })
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#008080', zIndex: 100000, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: welcome ? 'wait' : 'default' }}>
      {welcome ? (
        <div onClick={() => setAuthed(true)}>
          <Dialog title="Windows" width={360}>
            <div style={{ padding: 18, textAlign: 'center', lineHeight: '18px', fontSize: 13 }}>
              <div style={{ fontWeight: 'bold' }}>Welcome back, Mikhailov.</div>
              <div>Last successful login: 14 August 2003.</div>
            </div>
          </Dialog>
        </div>
      ) : (
        <Dialog title="Welcome to Windows" width={400}>
          <div style={{ background: '#fff', display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderBottom: '1px solid #808080' }}>
            <Flag />
            <div>
              <div style={{ fontFamily: 'Arial, sans-serif', fontSize: 15, fontWeight: 'bold', letterSpacing: 1 }}>MICROSOFT WINDOWS 98</div>
              <div>Welcome to HOME-PC-98</div>
            </div>
          </div>
          <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ color: '#800000', fontWeight: 'bold' }}>This computer is restricted.</div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 70 }}>User name:</span>
              <input readOnly value="VMikhailov" className="w98-field" style={{ flex: 1, border: 0, padding: '3px 4px', font: 'inherit', outline: 'none' }} />
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 70 }}>Password:</span>
              <input ref={input} type="password" autoComplete="off" value={pw} maxLength={24} className="w98-field"
                style={{ flex: 1, border: 0, padding: '3px 4px', font: 'inherit', outline: 'none' }}
                onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') submit() }} />
            </label>
            <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
              <button className="w98-button" onClick={submit}>OK</button>
              <button className="w98-button" onClick={cancel}>Cancel</button>
            </div>
          </div>
        </Dialog>
      )}
      {modal && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Dialog title={modal.title} width={340}>
            <MessageBox icon={modal.icon} text={modal.text} onOk={() => setModal(null)} />
          </Dialog>
        </div>
      )}
    </div>
  )
}
