import { useEffect, useRef, useState } from 'react'

export interface MenuItem { label?: string; action?: () => void; disabled?: boolean; sep?: boolean; checked?: boolean }
export interface Menu { label: string; items: MenuItem[] }

export default function MenuBar({ menus }: { menus: Menu[] }) {
  const [open, setOpen] = useState<number | null>(null)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (open === null) return
    const down = (e: PointerEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(null) }
    window.addEventListener('pointerdown', down)
    return () => window.removeEventListener('pointerdown', down)
  }, [open])

  return (
    <div ref={ref} style={{ display: 'flex', padding: '1px 0', borderBottom: '1px solid #808080', boxShadow: '0 1px #fff', flex: 'none' }}>
      {menus.map((m, i) => (
        <div key={m.label} style={{ position: 'relative' }} onMouseEnter={() => open !== null && setOpen(i)}>
          <div style={{ padding: '2px 8px', ...(open === i ? { background: '#000080', color: '#fff' } : {}) }}
            onClick={() => setOpen(open === i ? null : i)}>{m.label}</div>
          {open === i && (
            <div className="w98-menu" style={{ position: 'absolute', top: '100%', left: 0, zIndex: 20, minWidth: 150, padding: 2 }}>
              {m.items.map((it, j) => it.sep ? <div key={j} className="w98-menu-sep" /> : (
                <div key={j} className={`w98-menu-item ${it.disabled ? 'disabled' : ''}`} style={{ position: 'relative' }}
                  onClick={() => { setOpen(null); it.action?.() }}>
                  {it.checked && <span style={{ position: 'absolute', left: 6 }}>✓</span>}{it.label}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
