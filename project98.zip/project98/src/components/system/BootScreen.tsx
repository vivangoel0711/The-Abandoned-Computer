import { useEffect, useState } from 'react'

const LINES: { t: number; text: string; warn?: boolean }[] = [
  { t: 300, text: 'AMIBIOS (C) 1998 American Megatrends Inc.' },
  { t: 700, text: 'BIOS INITIALIZATION...' },
  { t: 1300, text: 'MEMORY TEST: 65536K OK' },
  { t: 2100, text: 'Detecting Primary Master ... WDC AC22100H' },
  { t: 2700, text: 'LOADING WINDOWS 98...' },
  { t: 3400, text: 'RESTORING USER PROFILE...' },
  { t: 4100, text: 'RECOVERING FILE SYSTEM... 3 files recovered from C:\\RECYCLED' },
  { t: 4900, text: 'WARNING:', warn: true },
  { t: 5200, text: 'Previous user session was never terminated.', warn: true },
]

export default function BootScreen({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    const timers = LINES.map((l, i) => setTimeout(() => setCount(i + 1), l.t))
    const done = setTimeout(onDone, 6400)
    const skip = () => { clearTimeout(done); onDone() }
    window.addEventListener('keydown', skip)
    return () => { timers.forEach(clearTimeout); clearTimeout(done); window.removeEventListener('keydown', skip) }
  }, [onDone])

  return (
    <div className="boot">
      {LINES.slice(0, count).map((l, i) => (
        <div key={i} className={l.warn ? 'warn' : ''} style={{ marginTop: l.warn && i === 7 ? 18 : 2 }}>{l.text}</div>
      ))}
      <div className="blink">_</div>
      <div style={{ position: 'absolute', bottom: 16, right: 24, fontSize: 11, opacity: 0.6 }}>Press any key to skip</div>
    </div>
  )
}
