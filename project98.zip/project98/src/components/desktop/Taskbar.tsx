import { APPLICATIONS } from '../../data/applications'
import { useWindowStore } from '../../store/windowStore'
import SystemTray from '../system/SystemTray'
import PixelIcon from './PixelIcon'

export default function Taskbar() {
  const windows = useWindowStore((s) => s.windows)
  const focusedId = useWindowStore((s) => s.focusedId)
  const startOpen = useWindowStore((s) => s.startOpen)
  const st = useWindowStore.getState

  const onTask = (id: string, minimized: boolean) => {
    if (id === focusedId && !minimized) st().minimize(id)
    else st().focus(id)
    st().setStartOpen(false)
  }

  return (
    <div className="taskbar" onContextMenu={(e) => e.preventDefault()}>
      <button data-start className={`w98-button ${startOpen ? 'pressed' : ''}`}
        style={{ minWidth: 54, height: 22, padding: '0 6px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: 4 }}
        onClick={() => st().setStartOpen(!startOpen)}>
        <svg width="16" height="16" viewBox="0 0 16 16" shapeRendering="crispEdges">
          <rect x="1" y="2" width="6" height="6" fill="#f00"/><rect x="8" y="1" width="7" height="7" fill="#0a0"/>
          <rect x="1" y="9" width="6" height="6" fill="#00f"/><rect x="8" y="9" width="7" height="6" fill="#fc0"/>
        </svg>
        Start
      </button>
      <div style={{ width: 2, height: 22, borderLeft: '1px solid #808080', borderRight: '1px solid #fff' }} />
      <div style={{ display: 'flex', gap: 3, flex: 1, minWidth: 0, overflow: 'hidden' }}>
        {windows.map((w) => {
          const def = APPLICATIONS.find((a) => a.id === w.appId)!
          const active = w.id === focusedId && !w.minimized
          return (
            <button key={w.id} className={`${active ? 'w98-inset' : 'w98-button'}`}
              style={{ flex: '0 1 160px', minWidth: 40, height: 22, padding: '0 6px', border: 0, font: 'inherit', fontWeight: active ? 'bold' : 'normal',
                display: 'flex', alignItems: 'center', gap: 4, overflow: 'hidden', whiteSpace: 'nowrap', textAlign: 'left',
                ...(active ? { backgroundImage: 'repeating-conic-gradient(#c0c0c0 0% 25%, #fff 0% 50%)', backgroundSize: '2px 2px' } : {}) }}
              onClick={() => onTask(w.id, w.minimized)}>
              <PixelIcon id={def.icon} size={14} />
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{w.title}</span>
            </button>
          )
        })}
      </div>
      <SystemTray />
    </div>
  )
}
