import { useEffect } from 'react'
import { useDesktopStore } from '../../store/desktopStore'
import { APPLICATIONS } from '../../data/applications'

interface Item { label: string; action?: () => void; disabled?: boolean; sep?: boolean; bold?: boolean }

export default function ContextMenu({ onOpenApp }: { onOpenApp: (id: string) => void }) {
  const menu = useDesktopStore((s) => s.contextMenu)
  const { closeContextMenu, refreshDesktop, arrangeIcons } = useDesktopStore.getState()

  useEffect(() => {
    if (!menu) return
    const close = () => closeContextMenu()
    window.addEventListener('pointerdown', close)
    window.addEventListener('blur', close)
    return () => { window.removeEventListener('pointerdown', close); window.removeEventListener('blur', close) }
  }, [menu, closeContextMenu])

  if (!menu) return null

  const items: Item[] = menu.target === 'desktop'
    ? [
        { label: 'Arrange Icons', action: arrangeIcons },
        { label: 'Refresh', action: refreshDesktop },
        { label: '', sep: true },
        { label: 'Paste', disabled: true },
        { label: '', sep: true },
        { label: 'Properties', action: () => alert('Display Properties\n\nWallpaper: (None)\nColor: Teal\n\nSomeone really loved teal.') },
      ]
    : [
        { label: 'Open', bold: true, action: () => onOpenApp(menu.target) },
        { label: '', sep: true },
        { label: 'Properties', action: () => alert(`${APPLICATIONS.find((a) => a.id === menu.target)?.title}\n\nType: Shortcut`) },
      ]

  const left = Math.min(menu.x, window.innerWidth - 170)
  const top = Math.min(menu.y, window.innerHeight - 28 - items.length * 20)

  return (
    <div className="w98-menu" style={{ position: 'fixed', left, top, zIndex: 10000, minWidth: 150, padding: 2 }}
         onPointerDown={(e) => e.stopPropagation()} onContextMenu={(e) => e.preventDefault()}>
      {items.map((it, i) =>
        it.sep ? <div key={i} className="w98-menu-sep" /> : (
          <div key={i} className={`w98-menu-item ${it.disabled ? 'disabled' : ''}`}
               style={{ fontWeight: it.bold ? 'bold' : undefined }}
               onClick={() => { it.action?.(); closeContextMenu() }}>
            {it.label}
          </div>
        ),
      )}
    </div>
  )
}
