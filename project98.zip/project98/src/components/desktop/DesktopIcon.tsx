import { useRef } from 'react'
import type { AppDefinition } from '../../data/applications'
import { useDesktopStore, GRID_X, GRID_Y, MARGIN } from '../../store/desktopStore'
import PixelIcon from './PixelIcon'

interface Props { app: AppDefinition; onOpen: (app: AppDefinition) => void }

export default function DesktopIcon({ app, onOpen }: Props) {
  const pos = useDesktopStore((s) => s.iconPositions[app.id]) ?? { x: MARGIN, y: MARGIN }
  const selected = useDesktopStore((s) => s.selectedIcon === app.id)
  const { selectIcon, moveIcon, openContextMenu } = useDesktopStore.getState()
  const drag = useRef<{ dx: number; dy: number; moved: boolean } | null>(null)
  const ref = useRef<HTMLDivElement>(null)

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return
    e.stopPropagation()
    selectIcon(app.id)
    drag.current = { dx: e.clientX - pos.x, dy: e.clientY - pos.y, moved: false }
    ref.current?.setPointerCapture(e.pointerId)
  }
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current
    if (!d || !ref.current) return
    d.moved = true
    ref.current.style.left = `${e.clientX - d.dx}px`
    ref.current.style.top = `${e.clientY - d.dy}px`
  }
  const onPointerUp = (e: React.PointerEvent) => {
    const d = drag.current
    drag.current = null
    if (!d || !d.moved) return
    const x = Math.min(window.innerWidth - 75, Math.max(0, e.clientX - d.dx))
    const y = Math.min(window.innerHeight - 28 - 80, Math.max(0, e.clientY - d.dy))
    moveIcon(app.id, {
      x: Math.round((x - MARGIN) / GRID_X) * GRID_X + MARGIN,
      y: Math.round((y - MARGIN) / GRID_Y) * GRID_Y + MARGIN,
    })
    if (ref.current) { ref.current.style.left = ''; ref.current.style.top = '' }
  }

  return (
    <div
      ref={ref}
      className={`desktop-icon ${selected ? 'selected' : ''}`}
      style={{ left: pos.x, top: pos.y }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onDoubleClick={() => onOpen(app)}
      onContextMenu={(e) => {
        e.preventDefault(); e.stopPropagation()
        selectIcon(app.id)
        openContextMenu({ x: e.clientX, y: e.clientY, target: app.id })
      }}
    >
      <PixelIcon id={app.icon} />
      <span className="label">{app.title}</span>
    </div>
  )
}
