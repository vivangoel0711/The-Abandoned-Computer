import type { AppId } from '../../data/applications'

export type IconId = AppId | 'folder' | 'floppy' | 'drive' | 'printer' | 'dialup' | 'cdrom'

export default function PixelIcon({ id, size = 32 }: { id: IconId; size?: number }) {
  const p = { width: size, height: size, viewBox: '0 0 32 32', shapeRendering: 'crispEdges' as const }
  switch (id) {
    case 'my-computer':
      return (<svg {...p}><rect x="4" y="4" width="24" height="17" fill="#c0c0c0" stroke="#000"/><rect x="6" y="6" width="20" height="13" fill="#008080" stroke="#808080"/><rect x="10" y="23" width="12" height="3" fill="#c0c0c0" stroke="#000"/><rect x="6" y="26" width="20" height="3" fill="#c0c0c0" stroke="#000"/></svg>)
    case 'my-documents':
    case 'file-explorer':
    case 'folder':
      return (<svg {...p}><path d="M3 8h9l2 3h15v16H3z" fill="#ffff00" stroke="#000"/><rect x="3" y="14" width="26" height="13" fill="#ffd700" stroke="#000"/></svg>)
    case 'recycle-bin':
      return (<svg {...p}><path d="M8 9h16l-2 19H10z" fill="#c0c0c0" stroke="#000"/><rect x="6" y="6" width="20" height="3" fill="#808080" stroke="#000"/><path d="M13 13v11M16 13v11M19 13v11" stroke="#000"/><path d="M14 3h4v3h-4z" fill="#008000" stroke="#000"/></svg>)
    case 'internet-explorer':
      return (<svg {...p}><circle cx="16" cy="16" r="11" fill="#1084d0" stroke="#000080"/><text x="16" y="22" textAnchor="middle" fontSize="18" fontWeight="bold" fontFamily="Arial" fill="#fff">e</text><ellipse cx="16" cy="16" rx="14" ry="5" fill="none" stroke="#ffd700" strokeWidth="2" transform="rotate(-25 16 16)"/></svg>)
    case 'notepad':
      return (<svg {...p}><rect x="7" y="4" width="18" height="24" fill="#fff" stroke="#000"/><rect x="7" y="4" width="18" height="4" fill="#000080"/><path d="M10 12h12M10 16h12M10 20h12M10 24h8" stroke="#808080"/></svg>)
    case 'calculator':
      return (<svg {...p}><rect x="6" y="3" width="20" height="26" fill="#c0c0c0" stroke="#000"/><rect x="8" y="5" width="16" height="6" fill="#9ccf9c" stroke="#000"/><g fill="#808080">{[0,1,2].flatMap((r)=>[0,1,2].map((c)=><rect key={`${r}${c}`} x={9+c*5} y={14+r*5} width="4" height="4"/>))}</g></svg>)
    case 'paint':
      return (<svg {...p}><rect x="5" y="6" width="22" height="20" rx="8" fill="#ffe4b5" stroke="#000"/><circle cx="12" cy="13" r="2" fill="#f00"/><circle cx="18" cy="11" r="2" fill="#00f"/><circle cx="22" cy="16" r="2" fill="#0a0"/><path d="M18 28l8-12" stroke="#8b4513" strokeWidth="3"/></svg>)
    case 'minesweeper':
      return (<svg {...p}><rect x="3" y="3" width="26" height="26" fill="#c0c0c0" stroke="#000"/><circle cx="16" cy="16" r="6" fill="#000"/><path d="M16 7v18M7 16h18M10 10l12 12M22 10L10 22" stroke="#000" strokeWidth="2"/><rect x="13" y="13" width="2" height="2" fill="#fff"/></svg>)
     case 'floppy':
      return (<svg {...p}><rect x="5" y="4" width="22" height="24" fill="#202080" stroke="#000"/><rect x="10" y="4" width="12" height="9" fill="#c0c0c0" stroke="#000"/><rect x="17" y="6" width="3" height="5" fill="#202080"/><rect x="9" y="17" width="14" height="10" fill="#fff" stroke="#000"/></svg>)
    case 'drive':
      return (<svg {...p}><rect x="3" y="12" width="26" height="12" fill="#c0c0c0" stroke="#000"/><rect x="5" y="20" width="12" height="2" fill="#808080"/><rect x="23" y="18" width="3" height="2" fill="#0f0"/><rect x="3" y="24" width="26" height="2" fill="#808080"/></svg>)
    case 'cdrom':
      return (<svg {...p}><rect x="3" y="10" width="26" height="14" fill="#c0c0c0" stroke="#000"/><circle cx="13" cy="17" r="5" fill="#e8e8ff" stroke="#000"/><circle cx="13" cy="17" r="1.5" fill="#808080"/><rect x="21" y="15" width="6" height="4" fill="#808080"/></svg>)
    case 'printer':
    case 'printers':
      return (<svg {...p}><rect x="9" y="4" width="14" height="9" fill="#fff" stroke="#000"/><rect x="4" y="12" width="24" height="12" fill="#c0c0c0" stroke="#000"/><rect x="8" y="20" width="16" height="8" fill="#fff" stroke="#000"/><rect x="22" y="15" width="3" height="2" fill="#0f0"/></svg>)
    case 'control-panel':
      return (<svg {...p}><rect x="4" y="6" width="24" height="20" fill="#c0c0c0" stroke="#000"/><circle cx="12" cy="15" r="4" fill="#f00" stroke="#000"/><circle cx="21" cy="13" r="3" fill="#00f" stroke="#000"/><rect x="8" y="21" width="16" height="2" fill="#808080"/></svg>)
    case 'cmd':
      return (<svg {...p}><rect x="3" y="5" width="26" height="22" fill="#000" stroke="#808080"/><text x="6" y="19" fontSize="9" fontFamily="monospace" fill="#c0c0c0">C:\_</text></svg>)
    case 'dialup':
      return (<svg {...p}><rect x="4" y="14" width="24" height="10" fill="#c0c0c0" stroke="#000"/><rect x="8" y="10" width="16" height="4" fill="#808080" stroke="#000"/><path d="M6 8c6-5 14-5 20 0" stroke="#000" fill="none"/></svg>)
    default:
      return (<svg {...p}><rect x="4" y="6" width="24" height="20" fill="#c0c0c0" stroke="#000"/><rect x="4" y="6" width="24" height="4" fill="#000080"/></svg>)
  }
}
