import { useEffect, useMemo, useState } from 'react'
import { APPLICATIONS, isImplemented, type AppId } from '../../data/applications'
import { useWindowStore } from '../../store/windowStore'
import PixelIcon, { type IconId } from './PixelIcon'

interface Entry { label: string; icon?: IconId; app?: AppId; sub?: Entry[]; sep?: boolean }

const leaf = (app: AppId, label?: string): Entry => ({ label: label ?? APPLICATIONS.find((a) => a.id === app)!.title, icon: app, app })
const SEP: Entry = { label: '', sep: true }

/** Only real, working entries are shown; menus grow as each app lands. */
const prune = (xs: Entry[]): Entry[] =>
  xs.flatMap((e) => {
    if (e.sep) return [e]
    if (e.sub) { const sub = prune(e.sub); return sub.length ? [{ ...e, sub }] : [] }
    return e.app && isImplemented(e.app) ? [e] : []
  })

const MENU: Entry[] = [
  { label: 'Programs', icon: 'folder', sub: [
    { label: 'Accessories', icon: 'folder', sub: [leaf('calculator'), leaf('notepad'), leaf('paint'), leaf('cmd')] },
    { label: 'Games', icon: 'folder', sub: [leaf('solitaire'), leaf('minesweeper'), leaf('super-retro-98')] },
    leaf('internet-explorer'),
  ] },
  { label: 'Documents', icon: 'my-documents', sub: [leaf('my-documents')] },
  { label: 'Settings', icon: 'control-panel', sub: [leaf('control-panel'), leaf('printers')] },
  { label: 'Find', icon: 'find', sub: [leaf('find', 'Files or Folders...')] },
  leaf('run', 'Run...'),
  SEP,
  leaf('shutdown', 'Shut Down...'),
]

function MenuList({ items, main }: { items: Entry[]; main?: boolean }) {
  const [open, setOpen] = useState<number | null>(null)
  const openApp = useWindowStore((s) => s.openApp)
  return (
    <div className="w98-menu" style={{ padding: 2, minWidth: 150, ...(main ? { flex: 1 } : { position: 'absolute', left: '100%', top: -2 }) }}>
      {items.map((e, i) => e.sep ? <div key={i} className="w98-menu-sep" /> : (
        <div key={i} style={{ position: 'relative' }} onMouseEnter={() => setOpen(e.sub ? i : null)}>
          <div className="w98-menu-item" style={{ display: 'flex', alignItems: 'center', gap: 8, padding: main ? '6px 6px' : '3px 6px', fontSize: main ? 12 : 11,
            ...(open === i ? { background: '#000080', color: '#fff' } : {}) }}
            onClick={() => e.app ? openApp(e.app) : setOpen(i)}>
            {e.icon && <PixelIcon id={e.icon} size={main ? 24 : 16} />}
            <span style={{ flex: 1 }}>{e.label}</span>
            {e.sub && <span>▶</span>}
          </div>
          {e.sub && open === i && <MenuList items={e.sub} />}
        </div>
      ))}
    </div>
  )
}

export default function StartMenu() {
  const startOpen = useWindowStore((s) => s.startOpen)
  const items = useMemo(() => prune(MENU), [])

  useEffect(() => {
    if (!startOpen) return
    const close = useWindowStore.getState().setStartOpen
    const onDown = (e: PointerEvent) => { if (!(e.target as Element).closest('[data-start]')) close(false) }
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close(false) }
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('keydown', onKey)
    return () => { window.removeEventListener('pointerdown', onDown); window.removeEventListener('keydown', onKey) }
  }, [startOpen])

  if (!startOpen) return null
  return (
    <div data-start style={{ position: 'fixed', left: 2, bottom: 28, zIndex: 9998, display: 'flex' }}>
      <div style={{ width: 22, background: 'linear-gradient(0deg,#000080,#1084d0)', color: '#fff', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', paddingBottom: 8 }}>
        <span style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)', fontWeight: 'bold', fontSize: 16, letterSpacing: 1 }}>Windows<span style={{ fontWeight: 'normal' }}>98</span></span>
      </div>
      <MenuList items={items} main />
    </div>
  )
}
