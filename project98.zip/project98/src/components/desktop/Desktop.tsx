import { APPLICATIONS, type AppDefinition, type AppId } from '../../data/applications'
import { useDesktopStore } from '../../store/desktopStore'
import { useWindowStore } from '../../store/windowStore'
import DesktopIcon from './DesktopIcon'
import ContextMenu from './ContextMenu'
import Taskbar from './Taskbar'
import StartMenu from './StartMenu'
import WindowManager from '../windows/WindowManager'

const openApp = (app: AppDefinition | string) =>
  useWindowStore.getState().openApp((typeof app === 'string' ? app : app.id) as AppId)

export default function Desktop() {
  const refreshing = useDesktopStore((s) => s.refreshing)
  const { selectIcon, openContextMenu, closeContextMenu } = useDesktopStore.getState()

  return (
    <>
      <div
        className="desktop"
        onPointerDown={() => { selectIcon(null); closeContextMenu(); useWindowStore.getState().focus(null) }}
        onContextMenu={(e) => { e.preventDefault(); openContextMenu({ x: e.clientX, y: e.clientY, target: 'desktop' }) }}
      >
        {!refreshing && APPLICATIONS.filter((a) => a.desktop).map((a) => (
          <DesktopIcon key={a.id} app={a} onOpen={openApp} />
        ))}
      </div>
      <WindowManager />
      <Taskbar />
      <StartMenu />
      <ContextMenu onOpenApp={openApp} />
    </>
  )
}
