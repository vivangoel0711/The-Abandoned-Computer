import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { APPLICATIONS, type AppId } from '../data/applications'

export const GRID_X = 80
export const GRID_Y = 84
export const MARGIN = 8

export interface Pos { x: number; y: number }
export interface MenuState { x: number; y: number; target: 'desktop' | AppId }

const defaultPositions = (): Record<string, Pos> => {
  const out: Record<string, Pos> = {}
  APPLICATIONS.filter((a) => a.desktop).forEach((a, i) => {
    out[a.id] = { x: MARGIN, y: MARGIN + i * GRID_Y }
  })
  return out
}

interface DesktopState {
  booted: boolean
  authed: boolean
  iconPositions: Record<string, Pos>
  selectedIcon: AppId | null
  contextMenu: MenuState | null
  refreshing: boolean
  setBooted: (v: boolean) => void
  setAuthed: (v: boolean) => void
  moveIcon: (id: string, p: Pos) => void
  selectIcon: (id: AppId | null) => void
  openContextMenu: (m: MenuState) => void
  closeContextMenu: () => void
  refreshDesktop: () => void
  arrangeIcons: () => void
}

export const useDesktopStore = create<DesktopState>()(
  persist(
    (set) => ({
      booted: false,
      authed: false,
      iconPositions: defaultPositions(),
      selectedIcon: null,
      contextMenu: null,
      refreshing: false,
      // Rebooting always logs the user out. Neither flag is persisted (see partialize).
      setBooted: (booted) => set(booted ? { booted } : { booted: false, authed: false }),
      setAuthed: (authed) => set({ authed }),
      moveIcon: (id, p) => set((s) => ({ iconPositions: { ...s.iconPositions, [id]: p } })),
      selectIcon: (selectedIcon) => set({ selectedIcon }),
      openContextMenu: (contextMenu) => set({ contextMenu }),
      closeContextMenu: () => set({ contextMenu: null }),
      refreshDesktop: () => {
        set({ refreshing: true, contextMenu: null })
        setTimeout(() => set({ refreshing: false }), 250)
      },
      arrangeIcons: () => set({ iconPositions: defaultPositions(), contextMenu: null }),
    }),
    {
      name: 'project98-desktop',
      partialize: (s) => ({ iconPositions: s.iconPositions }),
    },
  ),
)
