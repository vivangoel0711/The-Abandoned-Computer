import { create } from 'zustand'
import { APPLICATIONS, type AppId, type Params } from '../data/applications'
import { useDesktopStore } from './desktopStore'

export const TASKBAR_H = 28
export const MIN_W = 160
export const MIN_H = 100

export interface Rect { x: number; y: number; w: number; h: number }
export interface WinState extends Rect {
  id: string
  appId: AppId
  title: string
  minimized: boolean
  maximized: boolean
  z: number
  restore?: Rect
  params?: Params
}

interface WindowStore {
  windows: WinState[]
  focusedId: string | null
  zTop: number
  startOpen: boolean
  power: 'on' | 'off'
  openApp: (id: AppId, params?: Params) => void
  closeWindow: (id: string) => void
  minimize: (id: string) => void
  toggleMaximize: (id: string) => void
  focus: (id: string | null) => void
  setRect: (id: string, r: Partial<Rect>) => void
  setStartOpen: (v: boolean) => void
  shutDown: () => void
  restart: () => void
}

let seq = 0
const topVisible = (ws: WinState[]) =>
  [...ws].filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null

export const useWindowStore = create<WindowStore>()((set, get) => ({
  windows: [],
  focusedId: null,
  zTop: 1,
  startOpen: false,
  power: 'on',

  openApp: (id, params) => {
    const def = APPLICATIONS.find((a) => a.id === id)
    if (!def) return
    // Shortcuts (e.g. My Documents) resolve to their target app + params.
    if (def.target) return get().openApp(def.target.app, { ...def.target.params, ...params })
    const existing = def.single ? get().windows.find((w) => w.appId === id) : undefined
    if (existing) {
      if (params) set((s) => ({ windows: s.windows.map((w) => (w.id === existing.id ? { ...w, params } : w)) }))
      get().focus(existing.id)
      set({ startOpen: false })
      return
    }
    const { windows, zTop } = get()
    const vw = window.innerWidth, vh = window.innerHeight - TASKBAR_H
    const w = Math.min(def.w, vw - 8), h = Math.min(def.h, vh - 8)
    const off = (windows.length % 8) * 24
    const centered = def.kind === 'dialog'
    const win: WinState = {
      id: `${id}-${++seq}`, appId: id, title: def.title, minimized: false, maximized: false, z: zTop + 1, params,
      w, h,
      x: centered ? Math.round((vw - w) / 2) : Math.min(60 + off, Math.max(0, vw - w)),
      y: centered ? Math.round((vh - h) / 2) : Math.min(30 + off, Math.max(0, vh - h)),
    }
    set({ windows: [...windows, win], zTop: zTop + 1, focusedId: win.id, startOpen: false })
  },

  closeWindow: (id) => {
    const windows = get().windows.filter((w) => w.id !== id)
    set({ windows, focusedId: topVisible(windows) })
  },

  minimize: (id) => {
    const windows = get().windows.map((w) => (w.id === id ? { ...w, minimized: true } : w))
    set({ windows, focusedId: topVisible(windows) })
  },

  toggleMaximize: (id) =>
    set((s) => ({
      windows: s.windows.map((w) =>
        w.id !== id ? w
          : w.maximized ? { ...w, ...w.restore, maximized: false, restore: undefined }
          : { ...w, maximized: true, restore: { x: w.x, y: w.y, w: w.w, h: w.h } },
      ),
    })),

  focus: (id) => {
    if (id === null) return set({ focusedId: null })
    const z = get().zTop + 1
    set((s) => ({
      zTop: z, focusedId: id,
      windows: s.windows.map((w) => (w.id === id ? { ...w, minimized: false, z } : w)),
    }))
  },

  setRect: (id, r) =>
    set((s) => ({
      windows: s.windows.map((w) => {
        if (w.id !== id) return w
        const def = APPLICATIONS.find((a) => a.id === w.appId)
        const n = { ...w, ...r }
        n.w = Math.max(def?.minW ?? MIN_W, n.w)
        n.h = Math.max(def?.minH ?? MIN_H, n.h)
        // keep at least the title bar grabbable inside the desktop
        n.x = Math.min(Math.max(n.x, 100 - n.w), window.innerWidth - 100)
        n.y = Math.min(Math.max(n.y, 0), window.innerHeight - TASKBAR_H - 24)
        return n
      }),
    })),

  setStartOpen: (startOpen) => set({ startOpen }),
  shutDown: () => set({ power: 'off', windows: [], focusedId: null, startOpen: false }),
  restart: () => {
    set({ power: 'on', windows: [], focusedId: null, startOpen: false })
    useDesktopStore.getState().setBooted(false)
  },
}))
