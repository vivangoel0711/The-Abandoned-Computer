import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import * as core from '../fs/core'
import { SEED_VERSION, seedFs } from '../fs/seed'

/** The ONE filesystem every app reads and writes. Each action returns the core Result so the UI can show Windows-style errors. */
interface FsState {
  fs: core.Fs
  mkdir: (parent: string, name: string) => core.Result
  writeFile: (parent: string, name: string, data: { content?: string; asset?: string }) => core.Result
  rename: (id: string, name: string) => core.Result
  copyNode: (id: string, dest: string) => core.Result
  moveNode: (id: string, dest: string) => core.Result
  deleteNode: (id: string) => core.Result
  restore: (id: string) => core.Result
  purge: (id: string) => core.Result
  emptyRecycleBin: () => void
  reset: () => void
}

export const useFsStore = create<FsState>()(
  persist(
    (set, get) => {
      const run = (fn: (fs: core.Fs) => core.Result): core.Result => {
        const r = fn(get().fs)
        if (r.ok) set({ fs: r.fs })
        return r
      }
      return {
        fs: seedFs(),
        mkdir: (p, n) => run((fs) => core.mkdir(fs, p, n)),
        writeFile: (p, n, d) => run((fs) => core.writeFile(fs, p, n, d)),
        rename: (id, n) => run((fs) => core.rename(fs, id, n)),
        copyNode: (id, d) => run((fs) => core.copyNode(fs, id, d)),
        moveNode: (id, d) => run((fs) => core.moveNode(fs, id, d)),
        deleteNode: (id) => run((fs) => core.deleteNode(fs, id)),
        restore: (id) => run((fs) => core.restore(fs, id)),
        purge: (id) => run((fs) => core.purge(fs, id)),
        emptyRecycleBin: () => set({ fs: core.emptyRecycleBin(get().fs) }),
        reset: () => set({ fs: seedFs() }),
      }
    },
    {
      name: 'project98-fs',
      version: SEED_VERSION, // a stale seed version is dropped and re-seeded
      migrate: () => ({ fs: seedFs() }) as unknown as FsState,
      partialize: (s) => ({ fs: s.fs }) as unknown as FsState,
    },
  ),
)
