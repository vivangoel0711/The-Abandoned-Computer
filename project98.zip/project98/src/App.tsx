import { useDesktopStore } from './store/desktopStore'
import { useWindowStore } from './store/windowStore'
import BootScreen from './components/system/BootScreen'
import LoginScreen from './components/system/LoginScreen'
import ShutdownScreen from './components/system/ShutdownScreen'
import Desktop from './components/desktop/Desktop'

/** Flow: boot -> login -> welcome -> desktop. Neither flag is persisted, so refresh/restart always logs out. */
export default function App() {
  const booted = useDesktopStore((s) => s.booted)
  const authed = useDesktopStore((s) => s.authed)
  const setBooted = useDesktopStore((s) => s.setBooted)
  const power = useWindowStore((s) => s.power)
  if (power === 'off') return <ShutdownScreen />
  if (!booted) return <BootScreen onDone={() => setBooted(true)} />
  if (!authed) return <LoginScreen />
  return <Desktop />
}
