export type AppId =
  | 'my-computer' | 'file-explorer' | 'my-documents' | 'recycle-bin' | 'internet-explorer'
  | 'notepad' | 'calculator' | 'paint' | 'minesweeper' | 'solitaire' | 'super-retro-98'
  | 'media-player' | 'cmd' | 'control-panel' | 'printers' | 'image-viewer' | 'find' | 'run' | 'shutdown'

export type Params = Record<string, string>
/** window: resizable/maximizable. fixed: minimize+close only. dialog: close only. */
export type WindowKind = 'window' | 'fixed' | 'dialog'

export interface AppDefinition {
  id: AppId
  title: string
  exe: string
  aliases?: string[]
  icon: AppId
  desktop: boolean
  w: number
  h: number
  minW: number
  minH: number
  kind: WindowKind
  single: boolean
  /** true once the component for this app is really built (see components/applications/registry.tsx) */
  implemented: boolean
  /** shortcut: opening this app opens `target.app` with these params instead */
  target?: { app: AppId; params?: Params }
}

type Spec = Partial<AppDefinition> & Pick<AppDefinition, 'id' | 'title' | 'exe' | 'w' | 'h'>
const d = (o: Spec): AppDefinition =>
  ({ icon: o.id, desktop: false, kind: 'window', single: true, implemented: false, minW: 160, minH: 100, ...o })

export const APPLICATIONS: AppDefinition[] = [
  d({ id: 'my-computer', title: 'My Computer', exe: 'mycomp.exe', aliases: ['my computer', 'mycomputer'], w: 440, h: 340, minW: 300, minH: 220, desktop: true, implemented: true }),
  d({ id: 'file-explorer', title: 'Windows Explorer', exe: 'explorer.exe', w: 540, h: 380, minW: 320, minH: 220, single: false, implemented: true }),
  d({ id: 'my-documents', title: 'My Documents', exe: 'explorer.exe', aliases: ['my documents'], w: 540, h: 380, desktop: true, target: { app: 'file-explorer', params: { path: 'C:\\My Documents' } } }),
  d({ id: 'recycle-bin', title: 'Recycle Bin', exe: 'recycle.exe', w: 480, h: 340, desktop: true }),
  d({ id: 'internet-explorer', title: 'Internet Explorer', exe: 'iexplore.exe', w: 680, h: 480, minW: 420, minH: 300, desktop: true }),
  d({ id: 'notepad', title: 'Notepad', exe: 'notepad.exe', w: 480, h: 360, single: false, desktop: true }),
  d({ id: 'calculator', title: 'Calculator', exe: 'calc.exe', w: 236, h: 268, kind: 'fixed', implemented: true }),
  d({ id: 'paint', title: 'Paint', exe: 'mspaint.exe', w: 640, h: 460 }),
  d({ id: 'minesweeper', title: 'Minesweeper', exe: 'winmine.exe', w: 220, h: 310, kind: 'fixed', desktop: true }),
  d({ id: 'solitaire', title: 'Solitaire', exe: 'sol.exe', w: 700, h: 540, kind: 'fixed' }),
  d({ id: 'super-retro-98', title: 'Super Retro 98', exe: 'superretro.exe', aliases: ['super retro 98'], w: 680, h: 520, kind: 'fixed' }),
  d({ id: 'media-player', title: 'Windows Media Player', exe: 'mplayer2.exe', aliases: ['media player', 'wmplayer'], w: 360, h: 300, kind: 'fixed' }),
  d({ id: 'cmd', title: 'Command Prompt', exe: 'cmd.exe', aliases: ['command', 'ms-dos prompt'], w: 560, h: 340 }),
  d({ id: 'control-panel', title: 'Control Panel', exe: 'control.exe', aliases: ['control panel'], w: 480, h: 340, minW: 300, minH: 200 }),
  d({ id: 'printers', title: 'Printers', exe: 'printers.exe', w: 440, h: 300, minW: 300, minH: 200, implemented: true }),
  d({ id: 'image-viewer', title: 'Image Viewer', exe: 'imgview.exe', w: 560, h: 440, single: false }),
  d({ id: 'find', title: 'Find: All Files', exe: 'find.exe', aliases: ['files or folders'], w: 460, h: 340 }),
  d({ id: 'run', title: 'Run', exe: 'run.exe', w: 360, h: 160, kind: 'dialog', implemented: true }),
  d({ id: 'shutdown', title: 'Shut Down Windows', exe: 'shutdown.exe', w: 330, h: 190, kind: 'dialog', implemented: true }),
]

export const getApp = (id: AppId) => APPLICATIONS.find((a) => a.id === id)

/** An app (or shortcut to one) is implemented only if its real component exists. */
export const isImplemented = (id: AppId): boolean => {
  const a = getApp(id)
  return !!a && (a.target ? isImplemented(a.target.app) : a.implemented)
}
