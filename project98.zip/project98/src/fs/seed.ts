import type { AppId } from '../data/applications'
import type { Fs, FsNode } from './core'

/** Bump when seed content changes: a stale persisted filesystem is discarded and re-seeded. */
export const SEED_VERSION = 1

interface Opt { content?: string; asset?: string; app?: AppId; size?: number; hidden?: boolean; readonly?: boolean; protected?: boolean; date?: string; label?: string }
interface Entry { name: string; folder: boolean; opt: Opt; kids: Entry[] }
const dir = (name: string, kids: Entry[] = [], opt: Opt = {}): Entry => ({ name, folder: true, opt, kids })
const file = (name: string, opt: Opt = {}): Entry => ({ name, folder: false, opt, kids: [] })
const exe = (name: string, app: AppId, size: number): Entry => file(name, { app, size })
const bin = (name: string, size: number): Entry => file(name, { size })

const WIN98 = '1998-06-25'
const ts = (d: string) => Date.parse(`${d}T12:00:00Z`)

const C_TREE: Entry[] = [
  file('autoexec.bat', { hidden: false, date: WIN98, content: '@ECHO OFF\r\nPATH C:\\WINDOWS;C:\\WINDOWS\\COMMAND\r\nSET TEMP=C:\\WINDOWS\\TEMP\r\nSET BLASTER=A220 I5 D1 T4\r\n' }),
  file('config.sys', { date: WIN98, content: 'DEVICE=C:\\WINDOWS\\HIMEM.SYS\r\nDOS=HIGH,UMB\r\nFILES=40\r\n' }),
  dir('Windows', [
    file('win.ini', { content: '[windows]\r\nload=\r\nrun=\r\nNullPort=None\r\ndevice=Generic / Text Only,FILE:\r\n\r\n[Desktop]\r\nWallpaper=(None)\r\nTileWallpaper=0\r\n\r\n[intl]\r\niCountry=1\r\nsCountry=United States\r\n' }),
    file('system.ini', { content: '[boot]\r\nshell=Explorer.exe\r\nnetwork.drv=\r\n\r\n[386Enh]\r\nmouse=*vmouse, msmouse.vxd\r\nkeyboard=*vkd\r\n' }),
    exe('notepad.exe', 'notepad', 53248), exe('calc.exe', 'calculator', 91136), exe('mspaint.exe', 'paint', 344064),
    exe('winmine.exe', 'minesweeper', 27136), exe('sol.exe', 'solitaire', 131584), exe('explorer.exe', 'file-explorer', 143360),
    dir('System', [bin('kernel32.dll', 458752), bin('user32.dll', 405504), bin('gdi32.dll', 216064), bin('shell32.dll', 1458176), bin('vga.drv', 14336)]),
    dir('Fonts', [bin('arial.ttf', 65692), bin('cour.ttf', 76628), bin('times.ttf', 98168), bin('tahoma.ttf', 80220)]),
    dir('Media', [bin('tada.wav', 171000), bin('chimes.wav', 25000), bin('ding.wav', 12000), bin('The Microsoft Sound.wav', 442000)]),
    dir('Temp'),
  ], { protected: true }),
  dir('Program Files', [
    dir('Internet Explorer', [exe('iexplore.exe', 'internet-explorer', 87312)]),
    dir('Windows Media Player', [exe('mplayer2.exe', 'media-player', 20480)]),
    dir('Games'),
  ]),
  dir('My Documents', [
    dir('Personal', [dir('Private', [], { hidden: true })]),
    dir('Diary'), dir('Letters'), dir('Work'), dir('Classified'),
  ]),
  dir('My Pictures', [dir('Family'), dir('Friends'), dir('Travel'), dir('Historical Archive'), dir('Intelligence')]),
  dir('Games', [exe('SuperRetro98.exe', 'super-retro-98', 524288), exe('Solitaire.exe', 'solitaire', 131584), exe('Minesweeper.exe', 'minesweeper', 27136)]),
  dir('Intelligence', [
    dir('USA_ARCHIVES', [dir('PROJECT_ORION'), dir('PROJECT_SENTINEL', [dir('archived_photographs')]), dir('PROJECT_NORTHSTAR')]),
    dir('OPERATION_RED_WINDOW'), dir('COMMUNICATIONS'), dir('PHOTOGRAPHS'), dir('MAPS'), dir('ENCRYPTED_ARCHIVE'),
  ]),
  dir('Recycle Bin', [], { protected: true }),
]

// D: is a finished, write-protected backup CD (a disc cannot be modified).
const D_TREE: Entry[] = [
  file('AUTORUN.INF', { content: '[autorun]\r\nlabel=BACKUP_0803\r\n' }),
  file('BACKUP.LOG', { content: 'HOME-PC-98 BACKUP UTILITY v2.0\r\n\r\nSet     : BACKUP_0803   Disc 1 of 1\r\nStarted : 13 August 2003  23:41\r\nSource  : C:\\Intelligence\r\nQueued  : 41 files\r\nWritten : 33 files\r\nSkipped : 8 files  (media full)\r\n\r\nStatus  : INCOMPLETE\r\n' }),
]

export function seedFs(): Fs {
  const nodes: Record<string, FsNode> = {}
  const add = (parent: string, e: Entry, defDate: string) => {
    const id = `${parent}/${e.name.toLowerCase()}`
    const d = ts(e.opt.date ?? defDate)
    const { date: _d, ...o } = e.opt
    nodes[id] = { id, name: e.name, kind: e.folder ? 'folder' : 'file', parent, created: d, modified: d, ...o }
    e.kids.forEach((k) => add(id, k, e.opt.date ?? defDate))
  }
  const root = (id: string, name: string, tree: Entry[], date: string, extra: Partial<FsNode> = {}) => {
    nodes[id] = { id, name, kind: 'folder', parent: null, created: ts(date), modified: ts(date), ...extra }
    tree.forEach((e) => add(id, e, date))
  }
  root('c:', 'C:', C_TREE, WIN98, { label: 'HOME-PC' })
  root('d:', 'D:', D_TREE, '2003-08-13', { label: 'BACKUP_0803', readonly: true })
  return { version: SEED_VERSION, nextId: 1, nodes, deleted: {} }
}
