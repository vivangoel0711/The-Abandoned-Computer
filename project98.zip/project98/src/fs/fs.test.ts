import assert from 'node:assert/strict'
import * as F from './core'
import { seedFs } from './seed'

const ok = (r: F.Result) => { assert.ok(r.ok, r.ok ? '' : r.message); return r as Extract<F.Result, { ok: true }> }
const bad = (r: F.Result, code: F.FsError) => { assert.ok(!r.ok, 'expected failure'); assert.equal((r as { error: string }).error, code) }
const id = (fs: F.Fs, p: string) => { const n = F.resolve(fs, p); assert.ok(n, `missing ${p}`); return n!.id }
let fs = seedFs()

// seed integrity
for (const n of Object.values(fs.nodes)) {
  if (n.parent) assert.ok(fs.nodes[n.parent], `orphan ${n.id}`)
  const sibs = F.childrenOf(fs, n.parent ?? '__none').filter((s) => s.name.toLowerCase() === n.name.toLowerCase())
  if (n.parent) assert.equal(sibs.length, 1, `duplicate ${n.name}`)
}
for (const p of ['C:\\Windows\\System', 'C:\\My Documents\\Personal', 'C:\\My Pictures\\Historical Archive', 'C:\\Intelligence\\ENCRYPTED_ARCHIVE',
  'C:\\Games\\Solitaire.exe', 'C:\\Recycle Bin', 'D:\\BACKUP.LOG']) assert.ok(F.resolve(fs, p), p)
assert.equal(F.resolve(fs, 'c:/my documents/PERSONAL')?.name, 'Personal') // case-insensitive, either slash
assert.equal(F.pathOf(fs, id(fs, 'C:\\Windows\\System')), 'C:\\Windows\\System')
assert.equal(F.pathOf(fs, 'c:'), 'C:\\')
assert.equal(F.resolve(fs, 'C:\\nope\\x'), undefined)
assert.equal(F.resolve(fs, 'Z:\\'), undefined)

// hidden + sorting (folders always first)
const personal = id(fs, 'C:\\My Documents\\Personal')
assert.equal(F.list(fs, personal).length, 0)
assert.equal(F.list(fs, personal, { showHidden: true })[0].name, 'Private')
const names = F.list(fs, id(fs, 'C:\\Windows')).map((n) => n.name)
assert.deepEqual(names.slice(0, 4), ['Fonts', 'Media', 'System', 'Temp'])
assert.ok(F.list(fs, id(fs, 'C:\\Windows'), { sort: 'size', desc: true }).filter((n) => n.kind === 'file')[0].size! >= 343000)

// create / overwrite / validation (Notepad path)
const docs = id(fs, 'C:\\My Documents')
fs = ok(F.writeFile(fs, docs, 'note.txt', { content: 'hello' })).fs
fs = ok(F.writeFile(fs, docs, 'NOTE.TXT', { content: 'hello again' })).fs // overwrite, same file
assert.equal(F.childrenOf(fs, docs).filter((n) => n.name.toLowerCase() === 'note.txt').length, 1)
assert.equal(F.resolve(fs, 'C:\\My Documents\\note.txt')?.content, 'hello again')
bad(F.writeFile(fs, docs, 'a:b.txt', { content: '' }), 'invalid-name')
bad(F.writeFile(fs, docs, '  ', { content: '' }), 'invalid-name')
bad(F.mkdir(fs, docs, 'Personal'), 'exists')
bad(F.writeFile(fs, docs, 'Personal', { content: '' }), 'is-folder')

// rename
const note = id(fs, 'C:\\My Documents\\note.txt')
bad(F.rename(fs, note, 'Personal'), 'exists')
fs = ok(F.rename(fs, note, 'renamed.txt')).fs
assert.ok(F.resolve(fs, 'C:\\My Documents\\renamed.txt'))

// copy: deep, unique names, no self-nesting, drops readonly from CD
const copy1 = ok(F.copyNode(fs, id(fs, 'D:\\BACKUP.LOG'), docs))
fs = copy1.fs
assert.equal(fs.nodes[copy1.id!].readonly, undefined)
fs = ok(F.copyNode(fs, id(fs, 'C:\\My Documents\\renamed.txt'), docs)).fs
assert.ok(F.resolve(fs, 'C:\\My Documents\\Copy of renamed.txt'))
fs = ok(F.copyNode(fs, id(fs, 'C:\\My Documents\\renamed.txt'), docs)).fs
assert.ok(F.resolve(fs, 'C:\\My Documents\\Copy (2) of renamed.txt'))
bad(F.copyNode(fs, docs, id(fs, 'C:\\My Documents\\Personal')), 'into-self')
const before = Object.keys(fs.nodes).length
fs = ok(F.copyNode(fs, id(fs, 'C:\\Intelligence'), id(fs, 'C:\\Games'))).fs
assert.equal(Object.keys(fs.nodes).length - before, F.list(fs, 'c:', { showHidden: true }).length >= 0 ? Object.values(fs.nodes).filter((n) => F.pathOf(fs, n.id).startsWith('C:\\Games\\Intelligence')).length : 0)

// move
bad(F.moveNode(fs, id(fs, 'C:\\Games\\Intelligence'), id(fs, 'C:\\Games\\Intelligence\\MAPS')), 'into-self')
fs = ok(F.moveNode(fs, id(fs, 'C:\\Games\\Intelligence'), id(fs, 'C:\\Windows\\Temp'))).fs
assert.ok(F.resolve(fs, 'C:\\Windows\\Temp\\Intelligence\\MAPS'))

// protection + write-protected CD
bad(F.deleteNode(fs, id(fs, 'C:\\Windows')), 'protected')
bad(F.deleteNode(fs, id(fs, 'C:\\Windows\\System\\kernel32.dll')), 'protected')
bad(F.rename(fs, id(fs, 'C:\\Windows'), 'Win'), 'protected')
bad(F.deleteNode(fs, id(fs, 'C:\\Recycle Bin')), 'protected')
bad(F.deleteNode(fs, 'c:'), 'not-found')
bad(F.writeFile(fs, 'd:', 'x.txt', { content: 'x' }), 'readonly')
bad(F.deleteNode(fs, id(fs, 'D:\\BACKUP.LOG')), 'readonly')

// delete -> Recycle Bin -> restore to the original folder
const pic = ok(F.writeFile(fs, id(fs, 'C:\\My Pictures\\Family'), 'mum.jpg', { asset: '/assets/x.jpg' }))
fs = pic.fs
fs = ok(F.deleteNode(fs, pic.id!)).fs
assert.equal(F.resolve(fs, 'C:\\My Pictures\\Family\\mum.jpg'), undefined)
assert.equal(F.resolve(fs, 'C:\\Recycle Bin\\mum.jpg')?.id, pic.id)
assert.equal(fs.deleted[pic.id!].origParent, 'c:/my pictures/family')
fs = ok(F.restore(fs, pic.id!)).fs
assert.equal(F.pathOf(fs, pic.id!), 'C:\\My Pictures\\Family\\mum.jpg')
assert.equal(Object.keys(fs.deleted).length, 0)

// two deletes with the same name coexist; restore into a name clash renames
const a = ok(F.writeFile(fs, docs, 'dup.txt', { content: '1' })); fs = a.fs; fs = ok(F.deleteNode(fs, a.id!)).fs
const b = ok(F.writeFile(fs, docs, 'dup.txt', { content: '2' })); fs = b.fs; fs = ok(F.deleteNode(fs, b.id!)).fs
assert.equal(F.childrenOf(fs, F.RECYCLE_ID).length, 2)
const c = ok(F.writeFile(fs, docs, 'dup.txt', { content: '3' })); fs = c.fs
fs = ok(F.restore(fs, a.id!)).fs
assert.ok(F.resolve(fs, 'C:\\My Documents\\dup (1).txt'))

// restore when original folder was itself deleted -> falls back to C:\
const sub = ok(F.mkdir(fs, docs, 'Temp2')); fs = sub.fs
const f2 = ok(F.writeFile(fs, sub.id!, 'inner.txt', { content: 'i' })); fs = f2.fs
fs = ok(F.deleteNode(fs, f2.id!)).fs
fs = ok(F.deleteNode(fs, sub.id!)).fs
fs = ok(F.restore(fs, f2.id!)).fs
assert.equal(F.pathOf(fs, f2.id!), 'C:\\inner.txt')
// deleted folder restores with contents
const sub2 = ok(F.mkdir(fs, docs, 'Box')); fs = sub2.fs
fs = ok(F.writeFile(fs, sub2.id!, 'in.txt', { content: 'x' })).fs
fs = ok(F.deleteNode(fs, sub2.id!)).fs
assert.equal(F.resolve(fs, 'C:\\My Documents\\Box'), undefined)
fs = ok(F.restore(fs, sub2.id!)).fs
assert.ok(F.resolve(fs, 'C:\\My Documents\\Box\\in.txt'))

// purge / empty
bad(F.purge(fs, docs), 'not-deleted')
fs = ok(F.deleteNode(fs, sub2.id!)).fs
const nBefore = Object.keys(fs.nodes).length
fs = ok(F.purge(fs, sub2.id!)).fs
assert.equal(Object.keys(fs.nodes).length, nBefore - 2) // folder + its file
assert.equal(F.resolve(fs, 'C:\\Recycle Bin\\Box'), undefined)
fs = ok(F.deleteNode(fs, id(fs, 'C:\\My Documents\\renamed.txt'))).fs
fs = F.emptyRecycleBin(fs)
assert.equal(Object.keys(fs.deleted).length, 0)
assert.equal(F.childrenOf(fs, F.RECYCLE_ID).length, 0)

// persistence round-trip
const round = JSON.parse(JSON.stringify(fs)) as F.Fs
assert.deepEqual(round, fs)
assert.equal(F.resolve(round, 'C:\\My Documents\\Copy of renamed.txt')?.kind, 'file')

console.log('fs: all tests passed')
