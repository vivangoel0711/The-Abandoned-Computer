import type { AppId } from '../data/applications'

export interface FsNode {
  id: string
  name: string
  kind: 'folder' | 'file'
  parent: string | null
  content?: string // text files
  asset?: string // image/audio files under public/assets
  app?: AppId // executables launch this app
  size?: number // explicit size for fake binaries
  label?: string // volume label (drive roots)
  created: number
  modified: number
  hidden?: boolean
  readonly?: boolean
  protected?: boolean
}
export interface DeletedInfo { origParent: string; origName: string; deletedAt: number }
export interface Fs { version: number; nextId: number; nodes: Record<string, FsNode>; deleted: Record<string, DeletedInfo> }

export const RECYCLE_ID = 'c:/recycle bin'
export type FsError = 'exists' | 'invalid-name' | 'not-found' | 'readonly' | 'protected' | 'not-folder' | 'into-self' | 'is-folder' | 'not-deleted'
export type Result = { ok: true; fs: Fs; id?: string } | { ok: false; error: FsError; message: string }

const fail = (error: FsError, message: string): Result => ({ ok: false, error, message })
const BAD = /[\\/:*?"<>|]/

export const getNode = (fs: Fs, id: string) => fs.nodes[id]
export const childrenOf = (fs: Fs, id: string) => Object.values(fs.nodes).filter((n) => n.parent === id)
export const splitExt = (name: string) => { const i = name.lastIndexOf('.'); return i > 0 ? { base: name.slice(0, i), ext: name.slice(i) } : { base: name, ext: '' } }
export const extOf = (name: string) => splitExt(name).ext.slice(1).toLowerCase()

/** node first, root last */
export const ancestors = (fs: Fs, id: string): FsNode[] => {
  const out: FsNode[] = []
  let n: FsNode | undefined = fs.nodes[id]
  while (n) { out.push(n); n = n.parent ? fs.nodes[n.parent] : undefined }
  return out
}
export const pathOf = (fs: Fs, id: string): string => {
  const chain = ancestors(fs, id).reverse()
  if (!chain.length) return ''
  const [root, ...rest] = chain
  return rest.length ? `${root.name}\\${rest.map((n) => n.name).join('\\')}` : `${root.name}\\`
}
export const resolve = (fs: Fs, path: string): FsNode | undefined => {
  const parts = path.trim().replace(/\//g, '\\').split('\\').filter(Boolean)
  let cur = Object.values(fs.nodes).find((n) => n.parent === null && n.name.toLowerCase() === parts[0]?.toLowerCase())
  for (const p of parts.slice(1)) {
    if (!cur) return undefined
    cur = childrenOf(fs, cur.id).find((n) => n.name.toLowerCase() === p.toLowerCase())
  }
  return cur
}
export const sizeOf = (fs: Fs, id: string): number => {
  const n = fs.nodes[id]
  if (!n) return 0
  if (n.kind === 'file') return n.size ?? n.content?.length ?? 0
  return childrenOf(fs, id).reduce((s, c) => s + sizeOf(fs, c.id), 0)
}
export const isReadonly = (fs: Fs, id: string) => ancestors(fs, id).some((n) => n.readonly)
export const isProtected = (fs: Fs, id: string) => ancestors(fs, id).some((n) => n.protected)
export const inRecycleBin = (fs: Fs, id: string) => id !== RECYCLE_ID && ancestors(fs, id).some((n) => n.id === RECYCLE_ID)

export type SortKey = 'name' | 'type' | 'size' | 'date'
export const list = (fs: Fs, id: string, o: { showHidden?: boolean; sort?: SortKey; desc?: boolean } = {}): FsNode[] => {
  const { showHidden = false, sort = 'name', desc = false } = o
  const cmpName = (a: FsNode, b: FsNode) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
  const key: Record<SortKey, (a: FsNode, b: FsNode) => number> = {
    name: cmpName,
    type: (a, b) => extOf(a.name).localeCompare(extOf(b.name)) || cmpName(a, b),
    size: (a, b) => sizeOf(fs, a.id) - sizeOf(fs, b.id) || cmpName(a, b),
    date: (a, b) => a.modified - b.modified || cmpName(a, b),
  }
  // Explorer always keeps folders above files
  return childrenOf(fs, id).filter((n) => showHidden || !n.hidden)
    .sort((a, b) => (a.kind !== b.kind ? (a.kind === 'folder' ? -1 : 1) : desc ? -key[sort](a, b) : key[sort](a, b)))
}

const validName = (n: string) => { const t = n.trim(); return !!t && t.length <= 255 && !BAD.test(t) && t !== '.' && t !== '..' }
const taken = (fs: Fs, parent: string, name: string, ignore?: string) =>
  childrenOf(fs, parent).some((n) => n.id !== ignore && n.name.toLowerCase() === name.toLowerCase())
const pick = (fs: Fs, parent: string, cand: (i: number) => string) => { for (let i = 0; ; i++) { const c = cand(i); if (!taken(fs, parent, c)) return c } }
const withNode = (fs: Fs, n: FsNode): Fs => ({ ...fs, nodes: { ...fs.nodes, [n.id]: n } })
const subtree = (fs: Fs, id: string): FsNode[] => [fs.nodes[id], ...childrenOf(fs, id).flatMap((c) => subtree(fs, c.id))]
const folderTarget = (fs: Fs, id: string): Result | null => {
  const p = fs.nodes[id]
  if (!p) return fail('not-found', 'The system cannot find the path specified.')
  if (p.kind !== 'folder') return fail('not-folder', 'The destination is not a folder.')
  if (isReadonly(fs, id)) return fail('readonly', 'The disk is write-protected.')
  return null
}

export const mkdir = (fs: Fs, parentId: string, name: string): Result => {
  const bad = folderTarget(fs, parentId); if (bad) return bad
  if (!validName(name)) return fail('invalid-name', 'A file name cannot contain any of the following characters:\n\\ / : * ? " < > |')
  if (taken(fs, parentId, name.trim())) return fail('exists', `Cannot create folder ${name.trim()}: A file or folder with the name you specified already exists.`)
  const id = `n${fs.nextId}`, t = Date.now()
  return { ok: true, id, fs: { ...withNode(fs, { id, name: name.trim(), kind: 'folder', parent: parentId, created: t, modified: t }), nextId: fs.nextId + 1 } }
}

/** Create or overwrite a text file (used by Notepad, Paint, etc.). */
export const writeFile = (fs: Fs, parentId: string, name: string, data: { content?: string; asset?: string }): Result => {
  const bad = folderTarget(fs, parentId); if (bad) return bad
  if (!validName(name)) return fail('invalid-name', 'A file name cannot contain any of the following characters:\n\\ / : * ? " < > |')
  const ex = childrenOf(fs, parentId).find((n) => n.name.toLowerCase() === name.trim().toLowerCase())
  if (ex?.kind === 'folder') return fail('is-folder', `Cannot save ${name.trim()}: a folder with that name already exists.`)
  const t = Date.now()
  if (ex) return { ok: true, id: ex.id, fs: withNode(fs, { ...ex, ...data, modified: t }) }
  const id = `n${fs.nextId}`
  return { ok: true, id, fs: { ...withNode(fs, { id, name: name.trim(), kind: 'file', parent: parentId, ...data, created: t, modified: t }), nextId: fs.nextId + 1 } }
}

export const rename = (fs: Fs, id: string, newName: string): Result => {
  const n = fs.nodes[id]
  if (!n || !n.parent) return fail('not-found', 'The system cannot find the file specified.')
  if (isProtected(fs, id)) return fail('protected', `Cannot rename ${n.name}: Access is denied.`)
  if (isReadonly(fs, id)) return fail('readonly', 'The disk is write-protected.')
  if (!validName(newName)) return fail('invalid-name', 'A file name cannot contain any of the following characters:\n\\ / : * ? " < > |')
  if (taken(fs, n.parent, newName.trim(), id)) return fail('exists', `Cannot rename ${n.name}: A file with the name you specified already exists. Specify a different filename.`)
  return { ok: true, id, fs: withNode(fs, { ...n, name: newName.trim(), modified: Date.now() }) }
}

export const copyNode = (fs: Fs, id: string, destId: string): Result => {
  const n = fs.nodes[id]
  if (!n || !n.parent) return fail('not-found', 'The system cannot find the file specified.')
  const bad = folderTarget(fs, destId); if (bad) return bad
  if (ancestors(fs, destId).some((a) => a.id === id)) return fail('into-self', `Cannot copy ${n.name}: The destination folder is a subfolder of the source folder.`)
  const name = pick(fs, destId, (i) => (i === 0 ? n.name : i === 1 ? `Copy of ${n.name}` : `Copy (${i}) of ${n.name}`))
  const t = Date.now(), map = new Map<string, string>()
  let next = fs.nextId
  const nodes = { ...fs.nodes }
  for (const o of subtree(fs, id)) {
    const nid = `n${next++}`; map.set(o.id, nid)
    const { readonly: _r, protected: _p, label: _l, ...rest } = o
    nodes[nid] = { ...rest, id: nid, name: o.id === id ? name : o.name, parent: o.id === id ? destId : map.get(o.parent!)!, created: t }
  }
  return { ok: true, id: map.get(id), fs: { ...fs, nodes, nextId: next } }
}

export const moveNode = (fs: Fs, id: string, destId: string): Result => {
  const n = fs.nodes[id]
  if (!n || !n.parent) return fail('not-found', 'The system cannot find the file specified.')
  if (isProtected(fs, id)) return fail('protected', `Cannot move ${n.name}: Access is denied.`)
  if (isReadonly(fs, id)) return fail('readonly', 'The disk is write-protected.')
  const bad = folderTarget(fs, destId); if (bad) return bad
  if (ancestors(fs, destId).some((a) => a.id === id)) return fail('into-self', `Cannot move ${n.name}: The destination folder is a subfolder of the source folder.`)
  if (taken(fs, destId, n.name, id)) return fail('exists', `Cannot move ${n.name}: A file with that name already exists in the destination.`)
  return { ok: true, id, fs: withNode(fs, { ...n, parent: destId }) }
}

/** "Delete" = move to the Recycle Bin, remembering where it came from. */
export const deleteNode = (fs: Fs, id: string): Result => {
  const n = fs.nodes[id]
  if (!n || !n.parent) return fail('not-found', 'The system cannot find the file specified.')
  if (isProtected(fs, id)) return fail('protected', `Cannot delete ${n.name}: Access is denied.\n\nThe Windows folder is required for Windows to run.`)
  if (isReadonly(fs, id)) return fail('readonly', `Cannot delete ${n.name}: The disk is write-protected.`)
  if (id === RECYCLE_ID || inRecycleBin(fs, id)) return fail('protected', `Cannot delete ${n.name}: use Empty Recycle Bin.`)
  const name = pick(fs, RECYCLE_ID, (i) => { const { base, ext } = splitExt(n.name); return i === 0 ? n.name : `${base} (${i + 1})${ext}` })
  const moved = withNode(fs, { ...n, name, parent: RECYCLE_ID })
  return { ok: true, id, fs: { ...moved, deleted: { ...fs.deleted, [id]: { origParent: n.parent, origName: n.name, deletedAt: Date.now() } } } }
}

export const restore = (fs: Fs, id: string): Result => {
  const n = fs.nodes[id], info = fs.deleted[id]
  if (!n || !info) return fail('not-deleted', 'That item is not in the Recycle Bin.')
  const parentOk = !!fs.nodes[info.origParent] && fs.nodes[info.origParent].kind === 'folder' && !inRecycleBin(fs, info.origParent) && info.origParent !== RECYCLE_ID
  const dest = parentOk ? info.origParent : 'c:'
  const name = pick(fs, dest, (i) => { const { base, ext } = splitExt(info.origName); return i === 0 ? info.origName : `${base} (${i})${ext}` })
  const { [id]: _gone, ...deleted } = fs.deleted
  return { ok: true, id, fs: { ...withNode(fs, { ...n, name, parent: dest }), deleted } }
}

/** Permanently remove one Recycle Bin item (and its contents). */
export const purge = (fs: Fs, id: string): Result => {
  if (!fs.deleted[id]) return fail('not-deleted', 'That item is not in the Recycle Bin.')
  const gone = new Set(subtree(fs, id).map((n) => n.id))
  const nodes = Object.fromEntries(Object.entries(fs.nodes).filter(([k]) => !gone.has(k)))
  const deleted = Object.fromEntries(Object.entries(fs.deleted).filter(([k]) => k !== id))
  return { ok: true, fs: { ...fs, nodes, deleted } }
}
export const emptyRecycleBin = (fs: Fs): Fs =>
  Object.keys(fs.deleted).reduce((acc, id) => { const r = purge(acc, id); return r.ok ? r.fs : acc }, fs)
